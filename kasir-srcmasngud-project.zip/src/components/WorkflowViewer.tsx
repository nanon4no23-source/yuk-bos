import React, { useState } from 'react';
import { Copy, Check, Download, FileCode, CheckCircle2, Archive, Package, ExternalLink } from 'lucide-react';
import { RAW_WORKFLOW_YML, WORKFLOW_METADATA } from '../data/workflowContent';

export const WorkflowViewer: React.FC = () => {
  const [copied, setCopied] = useState(false);
  const [viewMode, setViewMode] = useState<'text' | 'table'>('text');

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(RAW_WORKFLOW_YML);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // Fallback
      const textArea = document.createElement('textarea');
      textArea.value = RAW_WORKFLOW_YML;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handleDownload = () => {
    const blob = new Blob([RAW_WORKFLOW_YML], { type: 'text/yaml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'build-apk.yml';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const lines = RAW_WORKFLOW_YML.trim().split('\n');

  return (
    <div className="space-y-4">
      {/* Banner Unduh ZIP Proyek */}
      <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-indigo-50 border border-emerald-200/80 rounded-2xl p-4 sm:p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-start gap-3.5">
          <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-xs">
            <Archive className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-bold text-slate-900 text-sm sm:text-base">
                File ZIP Proyek Lengkap Siap Diunduh
              </h3>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300">
                Lengkap + Workflow
              </span>
            </div>
            <p className="text-xs text-slate-600 mt-1 max-w-xl">
              Berisi seluruh kode sumber React/Vite, konfigurasi Android Capacitor (<code className="font-mono text-emerald-700 font-semibold">com.srcmasngud.kasir</code>), dan skrip build GitHub Actions (<code className="font-mono text-slate-700">.github/workflows/build-apk.yml</code>).
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <a
            id="btn-download-project-zip"
            href="/kasir-srcmasngud-project.zip"
            download="kasir-srcmasngud-project.zip"
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-bold rounded-xl bg-emerald-600 text-white hover:bg-emerald-700 active:bg-emerald-800 transition-all shadow-md hover:shadow-lg cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Unduh ZIP Proyek</span>
          </a>
        </div>
      </div>

      <div id="workflow-viewer-container" className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        {/* Header bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/80 gap-3">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
              <FileCode className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-semibold text-slate-800 text-base">{WORKFLOW_METADATA.filename}</span>
                <span className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full font-medium bg-emerald-50 text-emerald-700 border border-emerald-200/60">
                  <CheckCircle2 className="w-3 h-3" /> Valid YAML
                </span>
              </div>
              <p className="text-xs text-slate-500 font-mono mt-0.5">{WORKFLOW_METADATA.path}</p>
            </div>
          </div>

          {/* Action Buttons & Tabs */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* Mode Switcher */}
            <div className="flex items-center bg-slate-200/80 p-0.5 rounded-xl text-xs font-semibold">
              <button
                type="button"
                onClick={() => setViewMode('text')}
                className={`px-3 py-1.5 rounded-lg transition-all ${
                  viewMode === 'text' 
                    ? 'bg-white text-indigo-700 shadow-2xs font-bold' 
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Teks Polos (Siap Salin)
              </button>
              <button
                type="button"
                onClick={() => setViewMode('table')}
                className={`px-3 py-1.5 rounded-lg transition-all ${
                  viewMode === 'table' 
                    ? 'bg-white text-indigo-700 shadow-2xs font-bold' 
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Tampilan Baris
              </button>
            </div>

            <button
              id="btn-copy-workflow"
              onClick={handleCopy}
              type="button"
              className="inline-flex items-center justify-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-xl bg-white border border-slate-300 text-slate-700 hover:bg-slate-50 active:bg-slate-100 transition-colors shadow-2xs cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span className="text-emerald-700 font-bold">Tersalin!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 text-slate-500" />
                  <span>Salin Semua Teks</span>
                </>
              )}
            </button>

            <button
              id="btn-download-workflow"
              onClick={handleDownload}
              type="button"
              className="inline-flex items-center justify-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 active:bg-indigo-800 transition-colors shadow-sm cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Unduh .yml</span>
            </button>
          </div>
        </div>

      {/* Code Editor / Plain Text Preview */}
      {viewMode === 'text' ? (
        <div className="p-4 bg-slate-900 space-y-2">
          <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono pb-1 border-b border-slate-800">
            <span>Teks YAML Polos (Bisa di-klik, Ctrl+A untuk pilih semua, lalu Ctrl+C):</span>
            <span className="text-emerald-400 font-semibold">{lines.length} Baris Kode</span>
          </div>
          <textarea
            readOnly
            value={RAW_WORKFLOW_YML}
            onClick={(e) => (e.target as HTMLTextAreaElement).select()}
            className="w-full h-[520px] bg-slate-950 text-slate-100 font-mono text-xs p-4 rounded-xl border border-slate-800 focus:outline-hidden focus:border-indigo-500 selection:bg-indigo-800 selection:text-white leading-relaxed resize-none"
            title="Klik untuk memilih seluruh teks dan salin"
          />
        </div>
      ) : (
        <div className="bg-slate-900 text-slate-100 p-4 font-mono text-xs overflow-x-auto max-h-[580px] leading-relaxed select-text">
          <table className="border-collapse w-full">
            <tbody>
              {lines.map((line, idx) => {
                const lineNum = idx + 1;
                const isComment = line.trim().startsWith('#');
                const isSection = line.startsWith('  - name:') || line.startsWith('jobs:') || line.startsWith('on:') || line.startsWith('name:');

                return (
                  <tr key={lineNum} className="hover:bg-slate-800/60 transition-colors">
                    <td className="pr-4 text-right select-none text-slate-600 w-10 text-[11px] align-top">
                      {lineNum}
                    </td>
                    <td className="whitespace-pre align-top">
                      {isComment ? (
                        <span className="text-slate-500 italic">{line}</span>
                      ) : isSection ? (
                        <span className="text-emerald-400 font-semibold">{line}</span>
                      ) : line.includes('uses:') ? (
                        <span className="text-amber-300">{line}</span>
                      ) : line.includes('run:') ? (
                        <span className="text-cyan-300">{line}</span>
                      ) : (
                        <span className="text-slate-200">{line}</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  </div>
  );
};
