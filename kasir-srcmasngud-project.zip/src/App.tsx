import React, { useState, useEffect } from 'react';
import { 
  ShoppingCart, 
  Package, 
  Receipt, 
  Smartphone, 
  RotateCw, 
  FileCode, 
  Download, 
  Copy, 
  Check, 
  Layers, 
  CheckCircle2, 
  FolderGit2, 
  Clock,
  TrendingUp,
  Sparkles,
  GitBranch,
  Cpu,
  Terminal,
  HardDrive
} from 'lucide-react';
import { KasirView } from './components/KasirView';
import { StokBarangView } from './components/StokBarangView';
import { RiwayatView } from './components/RiwayatView';
import { StrukModal } from './components/StrukModal';
import { StorageManagerModal } from './components/StorageManagerModal';
import { WorkflowViewer } from './components/WorkflowViewer';
import { PipelineStepList } from './components/PipelineStepList';
import { SetupGuide } from './components/SetupGuide';
import { Product, Transaction } from './types';
import { INITIAL_PRODUCTS } from './data/sampleProducts';
import { WORKFLOW_METADATA, RAW_WORKFLOW_YML } from './data/workflowContent';
import { 
  initStorageAndMigrate, 
  saveProductsToDB, 
  addTransactionToDB, 
  clearAllTransactionsFromDB 
} from './utils/db';

export default function App() {
  // Navigation Tabs
  const [activeTab, setActiveTab] = useState<'kasir' | 'stok' | 'riwayat' | 'workflow'>('kasir');
  const [activeWorkflowSubtab, setActiveWorkflowSubtab] = useState<'workflow' | 'pipeline' | 'guide'>('workflow');
  const [copiedQuick, setCopiedQuick] = useState(false);
  const [isStorageModalOpen, setIsStorageModalOpen] = useState(false);

  // Persistent Products (Initialized with default/fallback, hydrated from IndexedDB)
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);

  // Persistent Transactions (Hydrated from IndexedDB)
  const [transactions, setTransactions] = useState<Transaction[]>([]);

  // Active Receipt Modal
  const [activeReceipt, setActiveReceipt] = useState<Transaction | null>(null);

  // Orientation State
  const [isLandscape, setIsLandscape] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return window.innerWidth > window.innerHeight;
    }
    return true;
  });

  // Load and migrate from IndexedDB on startup (Kapasitas Besar & Anti-Lag)
  useEffect(() => {
    initStorageAndMigrate()
      .then(({ products: loadedProds, transactions: loadedTxs }) => {
        if (loadedProds && loadedProds.length > 0) {
          setProducts(loadedProds);
        }
        if (loadedTxs) {
          setTransactions(loadedTxs);
        }
      })
      .catch((err) => {
        console.warn('Gagal inisialisasi IndexedDB:', err);
      });
  }, []);

  // Detect orientation change
  useEffect(() => {
    const handleResize = () => {
      setIsLandscape(window.innerWidth > window.innerHeight);
    };

    window.addEventListener('resize', handleResize);
    window.addEventListener('orientationchange', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('orientationchange', handleResize);
    };
  }, []);

  // Sync to IndexedDB asynchronously without blocking UI
  const handleUpdateProducts = (updated: Product[]) => {
    setProducts(updated);
    saveProductsToDB(updated).catch((err) => {
      console.error('Gagal menyimpan produk ke IndexedDB:', err);
    });
  };

  const handleCompleteTransaction = (tx: Transaction) => {
    // Instant UI update
    setTransactions((prev) => [tx, ...prev]);
    setActiveReceipt(tx);
    // Non-blocking O(1) write into IndexedDB
    addTransactionToDB(tx).catch((err) => {
      console.error('Gagal mencatat transaksi ke IndexedDB:', err);
    });
  };

  const handleClearHistory = () => {
    if (window.confirm('Hapus seluruh riwayat transaksi? Data tidak dapat dikembalikan.')) {
      setTransactions([]);
      clearAllTransactionsFromDB().catch((err) => {
        console.error('Gagal mengosongkan riwayat:', err);
      });
    }
  };

  const handleDataChanged = (newProducts: Product[], newTransactions: Transaction[]) => {
    setProducts(newProducts);
    setTransactions(newTransactions);
  };

  // Quick Copy & Download Workflow
  const handleQuickCopy = async () => {
    try {
      await navigator.clipboard.writeText(RAW_WORKFLOW_YML);
      setCopiedQuick(true);
      setTimeout(() => setCopiedQuick(false), 2000);
    } catch {
      setCopiedQuick(true);
      setTimeout(() => setCopiedQuick(false), 2000);
    }
  };

  const handleQuickDownload = () => {
    const blob = new Blob([RAW_WORKFLOW_YML], { type: 'text/yaml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'build-apk.yml';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Today's total sales
  const todayOmset = transactions.reduce((acc, t) => acc + t.total, 0);

  const formatRupiah = (val: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0
    }).format(val);
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 flex flex-col font-sans">
      {/* Top Header Bar */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-2xs">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-2">
          {/* Logo & Brand */}
          <div className="flex items-center gap-2.5 sm:gap-3 shrink-0">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-600 to-teal-700 text-white flex items-center justify-center shadow-sm">
              <ShoppingCart className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-sm sm:text-base font-black text-slate-900 tracking-tight">
                  KASIR SRC MASNGUD
                </h1>
                <span className="hidden sm:inline-block text-[11px] font-semibold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                  Android POS
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-mono">
                com.srcmasngud.kasir
              </p>
            </div>
          </div>

          {/* Orientation, Storage & Quick Metrics */}
          <div className="flex items-center gap-2">
            {/* Direct Project ZIP Download Button */}
            <a
              id="btn-header-download-zip"
              href="/kasir-srcmasngud-project.zip"
              download="kasir-srcmasngud-project.zip"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-xs font-bold shadow-xs hover:shadow-md transition-all cursor-pointer"
              title="Unduh Berkas ZIP Lengkap Proyek (dengan Android & 2 Kolom Landscape)"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Unduh ZIP Proyek</span>
              <span className="sm:hidden">Unduh ZIP</span>
            </a>

            {/* Storage Anti-Lag Button */}
            <button
              type="button"
              onClick={() => setIsStorageModalOpen(true)}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-xs font-semibold text-emerald-800 transition-colors cursor-pointer shadow-2xs"
              title="Kapasitas Penyimpanan & Optimasi Anti-Lag"
            >
              <HardDrive className="w-3.5 h-3.5 text-emerald-600" />
              <span className="hidden sm:inline">Penyimpanan</span>
              <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-full bg-emerald-200/80 text-emerald-900">
                Anti-Lag
              </span>
            </button>

            {/* Landscape Badge Indicator / Manual Toggle */}
            <button
              type="button"
              onClick={() => setIsLandscape((prev) => !prev)}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 border border-slate-200 text-xs font-semibold text-slate-700 transition-colors cursor-pointer"
              title="Klik untuk beralih mode 2 Kolom (Landscape) / 1 Kolom (Portrait)"
            >
              <Smartphone className={`w-3.5 h-3.5 transition-transform duration-300 ${isLandscape ? 'rotate-90 text-emerald-600' : 'text-slate-500'}`} />
              <span className="hidden sm:inline">
                {isLandscape ? 'Landscape (2 Kolom)' : 'Portrait'}
              </span>
            </button>

            {/* Quick Omset Tag */}
            <div className="hidden md:flex flex-col text-right px-2 py-0.5 border-l border-slate-200 pl-3">
              <span className="text-[10px] text-slate-400 font-medium">Total Omset:</span>
              <span className="text-xs font-bold text-emerald-700 font-mono">
                {formatRupiah(todayOmset)}
              </span>
            </div>

            {/* Workflow Action if needed */}
            {activeTab === 'workflow' && (
              <div className="flex items-center gap-1.5">
                <button
                  onClick={handleQuickCopy}
                  type="button"
                  className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
                  title="Salin YAML"
                >
                  {copiedQuick ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span className="hidden sm:inline">{copiedQuick ? 'Tersalin' : 'Salin'}</span>
                </button>
                <button
                  onClick={handleQuickDownload}
                  type="button"
                  className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white transition-colors"
                  title="Unduh YAML"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Unduh</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Primary Navigation Tabs */}
        <div className="bg-white border-t border-slate-100">
          <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
            <nav className="flex space-x-1 sm:space-x-3 overflow-x-auto no-scrollbar">
              <button
                id="nav-tab-kasir"
                type="button"
                onClick={() => setActiveTab('kasir')}
                className={`py-2.5 px-3 text-xs sm:text-sm font-bold border-b-2 flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === 'kasir'
                    ? 'border-emerald-600 text-emerald-700 bg-emerald-50/50'
                    : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
                }`}
              >
                <ShoppingCart className="w-4 h-4" />
                <span>Kasir (POS)</span>
                <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-emerald-100 text-emerald-800 ml-1">
                  2 Kolom
                </span>
              </button>

              <button
                id="nav-tab-stok"
                type="button"
                onClick={() => setActiveTab('stok')}
                className={`py-2.5 px-3 text-xs sm:text-sm font-bold border-b-2 flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === 'stok'
                    ? 'border-indigo-600 text-indigo-700 bg-indigo-50/50'
                    : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
                }`}
              >
                <Package className="w-4 h-4" />
                <span>Stok Barang</span>
                <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-indigo-100 text-indigo-800 ml-1">
                  {products.length}
                </span>
              </button>

              <button
                id="nav-tab-riwayat"
                type="button"
                onClick={() => setActiveTab('riwayat')}
                className={`py-2.5 px-3 text-xs sm:text-sm font-bold border-b-2 flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === 'riwayat'
                    ? 'border-emerald-600 text-emerald-700 bg-emerald-50/50'
                    : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
                }`}
              >
                <Receipt className="w-4 h-4" />
                <span>Riwayat &amp; Struk</span>
                {transactions.length > 0 && (
                  <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-slate-200 text-slate-700 ml-1">
                    {transactions.length}
                  </span>
                )}
              </button>

              <button
                id="nav-tab-workflow"
                type="button"
                onClick={() => setActiveTab('workflow')}
                className={`py-2.5 px-3 text-xs sm:text-sm font-bold border-b-2 flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === 'workflow'
                    ? 'border-slate-800 text-slate-900 bg-slate-100'
                    : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
                }`}
              >
                <FileCode className="w-4 h-4" />
                <span>Build APK &amp; Workflow</span>
              </button>
            </nav>
          </div>
        </div>
      </header>

      {/* Banner Unduh Berkas ZIP Proyek */}
      <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-indigo-700 text-white py-2.5 px-3 sm:px-6 shadow-sm border-b border-emerald-500/30">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2.5 text-xs">
          <div className="flex items-center gap-2 text-center sm:text-left">
            <span className="p-1 rounded-md bg-white/20 text-sm">📦</span>
            <span>
              <strong className="text-emerald-100">File ZIP Proyek Lengkap:</strong> Sudah disesuaikan dengan 2 Kolom Kasir &amp; Stok Barang + Source Code + Folder Android Capacitor.
            </span>
          </div>
          <a
            id="btn-banner-download-zip"
            href="/kasir-srcmasngud-project.zip"
            download="kasir-srcmasngud-project.zip"
            className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-white text-emerald-800 hover:bg-emerald-50 font-bold shadow-xs whitespace-nowrap transition-all cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-emerald-700" />
            <span>Klik Untuk Unduh ZIP</span>
          </a>
        </div>
      </div>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 lg:px-8 py-5 space-y-6">
        
        {/* TAB 1: KASIR (POS) */}
        {activeTab === 'kasir' && (
          <KasirView
            products={products}
            onUpdateProducts={handleUpdateProducts}
            onCompleteTransaction={handleCompleteTransaction}
            isLandscape={isLandscape}
          />
        )}

        {/* TAB 2: STOK BARANG */}
        {activeTab === 'stok' && (
          <StokBarangView
            products={products}
            onUpdateProducts={handleUpdateProducts}
            isLandscape={isLandscape}
          />
        )}

        {/* TAB 3: RIWAYAT TRANSAKSI */}
        {activeTab === 'riwayat' && (
          <RiwayatView
            transactions={transactions}
            onSelectReceipt={(tx) => setActiveReceipt(tx)}
            onClearHistory={handleClearHistory}
            onOpenStorageManager={() => setIsStorageModalOpen(true)}
          />
        )}

        {/* TAB 4: WORKFLOW APK & SETTINGS */}
        {activeTab === 'workflow' && (
          <div className="space-y-6">
            <section id="banner-overview" className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                <div className="space-y-2 max-w-2xl">
                  <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Sintaks Workflow Terverifikasi Valid
                  </div>
                  <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                    GitHub Actions: Build APK Android
                  </h2>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    Workflow ini digunakan untuk mem-build aplikasi Kasir POS (<code className="font-mono text-indigo-600 font-semibold">{WORKFLOW_METADATA.appId}</code>) menjadi file APK Android siap pakai.
                  </p>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-3">
                    <div className="flex items-center gap-1.5 text-slate-500 text-xs font-medium">
                      <GitBranch className="w-3.5 h-3.5 text-indigo-500" />
                      <span>Target Branch</span>
                    </div>
                    <p className="text-sm font-bold text-slate-800 mt-1">main &amp; master</p>
                  </div>

                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-3">
                    <div className="flex items-center gap-1.5 text-slate-500 text-xs font-medium">
                      <Cpu className="w-3.5 h-3.5 text-blue-500" />
                      <span>Runner</span>
                    </div>
                    <p className="text-sm font-bold text-slate-800 mt-1">ubuntu-latest</p>
                  </div>

                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 col-span-2 sm:col-span-1">
                    <div className="flex items-center gap-1.5 text-slate-500 text-xs font-medium">
                      <Terminal className="w-3.5 h-3.5 text-emerald-500" />
                      <span>Output File</span>
                    </div>
                    <p className="text-sm font-bold text-emerald-700 mt-1">.apk (Debug/Release)</p>
                  </div>
                </div>
              </div>
            </section>

            {/* Subtabs for Workflow */}
            <div className="flex items-center border-b border-slate-200">
              <nav className="flex space-x-3">
                <button
                  type="button"
                  onClick={() => setActiveWorkflowSubtab('workflow')}
                  className={`py-2 px-3 text-xs font-bold border-b-2 flex items-center gap-1.5 transition-colors ${
                    activeWorkflowSubtab === 'workflow'
                      ? 'border-indigo-600 text-indigo-600'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <FileCode className="w-3.5 h-3.5" />
                  <span>Kode YAML Workflow</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveWorkflowSubtab('pipeline')}
                  className={`py-2 px-3 text-xs font-bold border-b-2 flex items-center gap-1.5 transition-colors ${
                    activeWorkflowSubtab === 'pipeline'
                      ? 'border-indigo-600 text-indigo-600'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>14 Langkah Pipeline</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveWorkflowSubtab('guide')}
                  className={`py-2 px-3 text-xs font-bold border-b-2 flex items-center gap-1.5 transition-colors ${
                    activeWorkflowSubtab === 'guide'
                      ? 'border-indigo-600 text-indigo-600'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <FolderGit2 className="w-3.5 h-3.5" />
                  <span>Panduan GitHub</span>
                </button>
              </nav>
            </div>

            {activeWorkflowSubtab === 'workflow' && <WorkflowViewer />}
            {activeWorkflowSubtab === 'pipeline' && <PipelineStepList />}
            {activeWorkflowSubtab === 'guide' && <SetupGuide />}
          </div>
        )}
      </main>

      {/* Struk Modal */}
      {activeReceipt && (
        <StrukModal
          transaction={activeReceipt}
          onClose={() => setActiveReceipt(null)}
          onNewTransaction={() => {
            setActiveReceipt(null);
            setActiveTab('kasir');
          }}
        />
      )}

      {/* Storage Manager Modal (Kapasitas Longgar & Anti-Lag) */}
      {isStorageModalOpen && (
        <StorageManagerModal
          onClose={() => setIsStorageModalOpen(false)}
          onDataChanged={handleDataChanged}
        />
      )}

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-4 text-center text-xs text-slate-500 mt-auto">
        <p>
          Aplikasi Kasir POS SRC Masngud • Tampilan 2 Kolom Landscape Android • Penyimpanan Lokal Dilonggarkan (IndexedDB Anti-Lag)
        </p>
      </footer>
    </div>
  );
}
