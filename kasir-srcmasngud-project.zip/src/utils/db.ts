import { Product, Transaction } from '../types';
import { INITIAL_PRODUCTS } from '../data/sampleProducts';

const DB_NAME = 'KasirSRCDatabase';
const DB_VERSION = 1;
const STORE_PRODUCTS = 'products';
const STORE_TRANSACTIONS = 'transactions';

let dbPromise: Promise<IDBDatabase> | null = null;

/**
 * Membuka koneksi ke IndexedDB lokal browser / Android WebView.
 * Kapasitas IndexedDB jauh lebih besar (ratusan Megabyte hingga puluhan Gigabyte)
 * dibandingkan LocalStorage yang hanya terbatas 5MB dan memicu lag saat transaksi banyak.
 */
export function getDB(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;

  dbPromise = new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB tidak didukung pada perangkat ini.'));
      return;
    }

    const request = window.indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;

      // Object Store: Produk
      if (!db.objectStoreNames.contains(STORE_PRODUCTS)) {
        const productStore = db.createObjectStore(STORE_PRODUCTS, { keyPath: 'id' });
        productStore.createIndex('name', 'name', { unique: false });
        productStore.createIndex('barcode', 'barcode', { unique: false });
        productStore.createIndex('category', 'category', { unique: false });
      }

      // Object Store: Transaksi Penjualan
      if (!db.objectStoreNames.contains(STORE_TRANSACTIONS)) {
        const txStore = db.createObjectStore(STORE_TRANSACTIONS, { keyPath: 'id' });
        txStore.createIndex('invoiceNumber', 'invoiceNumber', { unique: false });
        txStore.createIndex('date', 'date', { unique: false });
      }
    };

    request.onsuccess = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      resolve(db);
    };

    request.onerror = (event) => {
      reject((event.target as IDBOpenDBRequest).error);
    };
  });

  return dbPromise;
}

/**
 * Inisialisasi awal dan migrasi otomatis dari LocalStorage lama ke IndexedDB.
 * Mencegah kehilangan data transaksi lama milik pengguna.
 */
export async function initStorageAndMigrate(): Promise<{
  products: Product[];
  transactions: Transaction[];
  migratedFromLocalStorage: boolean;
}> {
  let migrated = false;
  try {
    const db = await getDB();

    // Cek apakah ada data produk di IndexedDB
    let products = await getAllProductsFromDB(db);
    let transactions = await getAllTransactionsFromDB(db);

    // Cek jika IndexedDB masih kosong tapi ada data di localStorage lama
    if (products.length === 0 && typeof localStorage !== 'undefined') {
      const oldProdStr = localStorage.getItem('kasir_products');
      if (oldProdStr) {
        try {
          const parsed = JSON.parse(oldProdStr);
          if (Array.isArray(parsed) && parsed.length > 0) {
            await saveProductsToDB(parsed);
            products = parsed;
            migrated = true;
          }
        } catch (e) {
          console.error('Gagal migrasi produk dari localStorage:', e);
        }
      }
    }

    if (transactions.length === 0 && typeof localStorage !== 'undefined') {
      const oldTxStr = localStorage.getItem('kasir_transactions');
      if (oldTxStr) {
        try {
          const parsed = JSON.parse(oldTxStr);
          if (Array.isArray(parsed) && parsed.length > 0) {
            await batchAddTransactionsToDB(parsed);
            transactions = parsed;
            migrated = true;
          }
        } catch (e) {
          console.error('Gagal migrasi transaksi dari localStorage:', e);
        }
      }
    }

    // Jika produk masih kosong (aplikasi baru dibuka pertama kali), gunakan INITIAL_PRODUCTS
    if (products.length === 0) {
      await saveProductsToDB(INITIAL_PRODUCTS);
      products = INITIAL_PRODUCTS;
    }

    // Setelah berhasil migrasi ke IndexedDB, bersihkan data berat di localStorage
    // agar memori utama tidak terbebani
    if (migrated && typeof localStorage !== 'undefined') {
      localStorage.removeItem('kasir_transactions');
      localStorage.removeItem('kasir_products');
      localStorage.setItem('kasir_db_migrated_v1', 'true');
    }

    return { products, transactions, migratedFromLocalStorage: migrated };
  } catch (err) {
    console.warn('Gagal memuat IndexedDB, fallback ke memori/localStorage:', err);
    // Fallback darurat
    let fbProducts = INITIAL_PRODUCTS;
    let fbTransactions: Transaction[] = [];
    if (typeof localStorage !== 'undefined') {
      try {
        const p = localStorage.getItem('kasir_products');
        if (p) fbProducts = JSON.parse(p);
        const t = localStorage.getItem('kasir_transactions');
        if (t) fbTransactions = JSON.parse(t);
      } catch {
        // Abaikan
      }
    }
    return { products: fbProducts, transactions: fbTransactions, migratedFromLocalStorage: false };
  }
}

// ---------------- PRODUK OPERATIONS ----------------

export async function getAllProducts(): Promise<Product[]> {
  try {
    const db = await getDB();
    const products = await getAllProductsFromDB(db);
    return products.length > 0 ? products : INITIAL_PRODUCTS;
  } catch {
    return INITIAL_PRODUCTS;
  }
}

function getAllProductsFromDB(db: IDBDatabase): Promise<Product[]> {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_PRODUCTS, 'readonly');
    const store = tx.objectStore(STORE_PRODUCTS);
    const request = store.getAll();

    request.onsuccess = () => resolve(request.result || []);
    request.onerror = () => reject(request.error);
  });
}

export async function saveProductsToDB(products: Product[]): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_PRODUCTS, 'readwrite');
    const store = tx.objectStore(STORE_PRODUCTS);

    // Clear and batch re-insert
    store.clear();
    products.forEach((p) => {
      store.put(p);
    });

    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function upsertSingleProduct(product: Product): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_PRODUCTS, 'readwrite');
    const store = tx.objectStore(STORE_PRODUCTS);
    store.put(product);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function deleteProductFromDB(id: string): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_PRODUCTS, 'readwrite');
    const store = tx.objectStore(STORE_PRODUCTS);
    store.delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

// ---------------- TRANSAKSI OPERATIONS (O(1) NON-BLOCKING) ----------------

export async function getAllTransactions(): Promise<Transaction[]> {
  try {
    const db = await getDB();
    return await getAllTransactionsFromDB(db);
  } catch {
    return [];
  }
}

function getAllTransactionsFromDB(db: IDBDatabase): Promise<Transaction[]> {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_TRANSACTIONS, 'readonly');
    const store = tx.objectStore(STORE_TRANSACTIONS);
    const request = store.getAll();

    request.onsuccess = () => {
      const results: Transaction[] = request.result || [];
      // Urutkan transaksi terbaru di atas (id: 'tx-timestamp')
      results.sort((a, b) => {
        const tA = parseInt(a.id.replace('tx-', ''), 10) || 0;
        const tB = parseInt(b.id.replace('tx-', ''), 10) || 0;
        return tB - tA;
      });
      resolve(results);
    };
    request.onerror = () => reject(request.error);
  });
}

/**
 * Menyimpan 1 transaksi baru secara asinkron tanpa memblokir thread UI.
 * Tidak perlu memproses ulang atau me-rewrite ribuan transaksi sebelumnya!
 */
export async function addTransactionToDB(transaction: Transaction): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_TRANSACTIONS, 'readwrite');
    const store = tx.objectStore(STORE_TRANSACTIONS);
    store.put(transaction);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function batchAddTransactionsToDB(transactions: Transaction[]): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_TRANSACTIONS, 'readwrite');
    const store = tx.objectStore(STORE_TRANSACTIONS);
    transactions.forEach((item) => store.put(item));
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function clearAllTransactionsFromDB(): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_TRANSACTIONS, 'readwrite');
    const store = tx.objectStore(STORE_TRANSACTIONS);
    store.clear();
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

/**
 * Mengarsipkan / menghapus transaksi yang sudah lama (misal lebih dari X hari)
 * untuk mengoptimalkan kecepatan pencarian dan memori perangkat.
 */
export async function archiveOldTransactions(daysOld: number): Promise<{ removedCount: number; remainingTransactions: Transaction[] }> {
  const db = await getDB();
  const all = await getAllTransactionsFromDB(db);
  const cutoffTime = Date.now() - (daysOld * 24 * 60 * 60 * 1000);

  const remaining: Transaction[] = [];
  const toDeleteIds: string[] = [];

  all.forEach((tx) => {
    const txTimestamp = parseInt(tx.id.replace('tx-', ''), 10);
    if (!isNaN(txTimestamp) && txTimestamp < cutoffTime) {
      toDeleteIds.push(tx.id);
    } else {
      remaining.push(tx);
    }
  });

  if (toDeleteIds.length > 0) {
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_TRANSACTIONS, 'readwrite');
      const store = tx.objectStore(STORE_TRANSACTIONS);
      toDeleteIds.forEach((id) => store.delete(id));
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  return { removedCount: toDeleteIds.length, remainingTransactions: remaining };
}

// ---------------- ESTIMASI KAPASITAS & BACKUP ----------------

export interface StorageEstimateInfo {
  usedBytes: number;
  quotaBytes: number;
  usedFormatted: string;
  quotaFormatted: string;
  percentUsed: number;
  isIndexedDB: boolean;
  productCount: number;
  transactionCount: number;
}

function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

export async function getStorageEstimate(): Promise<StorageEstimateInfo> {
  let used = 0;
  let quota = 0;
  let hasStorageManager = false;

  if (typeof navigator !== 'undefined' && navigator.storage && navigator.storage.estimate) {
    try {
      const estimate = await navigator.storage.estimate();
      used = estimate.usage || 0;
      quota = estimate.quota || 0;
      hasStorageManager = true;
    } catch {
      // Abaikan jika ditolak
    }
  }

  // Jika estimate tidak ada (misal Android WebView lama), perkirakan dari ukuran data
  let pCount = 0;
  let txCount = 0;

  try {
    const db = await getDB();
    const p = await getAllProductsFromDB(db);
    const t = await getAllTransactionsFromDB(db);
    pCount = p.length;
    txCount = t.length;

    if (!hasStorageManager || used === 0) {
      // Perkiraan kasar stringify
      const approxBytes = JSON.stringify(p).length + JSON.stringify(t).length;
      used = approxBytes * 2; // UTF-16 / B-Tree index overhead
      quota = 1024 * 1024 * 1024; // 1 GB perkiraan kuota WebView modern
    }
  } catch {
    // Abaikan
  }

  const percentUsed = quota > 0 ? Number(((used / quota) * 100).toFixed(2)) : 0;

  return {
    usedBytes: used,
    quotaBytes: quota,
    usedFormatted: formatBytes(used),
    quotaFormatted: formatBytes(quota),
    percentUsed,
    isIndexedDB: true,
    productCount: pCount,
    transactionCount: txCount
  };
}

/**
 * Ekspor seluruh data toko (Produk + Riwayat Transaksi) ke file JSON
 * untuk backup offline yang aman.
 */
export async function exportAllDataJSON(): Promise<string> {
  const db = await getDB();
  const products = await getAllProductsFromDB(db);
  const transactions = await getAllTransactionsFromDB(db);

  const backupPayload = {
    appName: 'Kasir POS SRC Masngud',
    appId: 'com.srcmasngud.kasir',
    version: '1.0.0',
    exportDate: new Date().toISOString(),
    totalProducts: products.length,
    totalTransactions: transactions.length,
    data: {
      products,
      transactions
    }
  };

  return JSON.stringify(backupPayload, null, 2);
}

/**
 * Pulihkan / Impor data dari file JSON cadangan.
 */
export async function importDataJSON(jsonString: string): Promise<{
  success: boolean;
  productsCount: number;
  transactionsCount: number;
  products: Product[];
  transactions: Transaction[];
  message: string;
}> {
  try {
    const parsed = JSON.parse(jsonString);
    const rawProducts = parsed?.data?.products || parsed?.products;
    const rawTransactions = parsed?.data?.transactions || parsed?.transactions;

    if (!Array.isArray(rawProducts) && !Array.isArray(rawTransactions)) {
      throw new Error('Format file cadangan tidak valid (data produk atau transaksi tidak ditemukan).');
    }

    const validProducts: Product[] = Array.isArray(rawProducts) ? rawProducts : [];
    const validTransactions: Transaction[] = Array.isArray(rawTransactions) ? rawTransactions : [];

    if (validProducts.length > 0) {
      await saveProductsToDB(validProducts);
    }

    if (validTransactions.length > 0) {
      await batchAddTransactionsToDB(validTransactions);
    }

    const db = await getDB();
    const updatedProducts = await getAllProductsFromDB(db);
    const updatedTransactions = await getAllTransactionsFromDB(db);

    return {
      success: true,
      productsCount: validProducts.length,
      transactionsCount: validTransactions.length,
      products: updatedProducts,
      transactions: updatedTransactions,
      message: `Berhasil memulihkan ${validProducts.length} barang dan ${validTransactions.length} transaksi.`
    };
  } catch (err: any) {
    return {
      success: false,
      productsCount: 0,
      transactionsCount: 0,
      products: [],
      transactions: [],
      message: err?.message || 'Gagal membaca file JSON cadangan.'
    };
  }
}
