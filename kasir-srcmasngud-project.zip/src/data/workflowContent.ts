import { PipelineStep, WorkflowMetadata } from '../types';

export const WORKFLOW_METADATA: WorkflowMetadata = {
  name: 'Build Android APK (Capacitor)',
  filename: 'build-apk.yml',
  path: '.github/workflows/build-apk.yml',
  appId: 'com.srcmasngud.kasir',
  appName: 'Kasir',
  jdkVersion: 'Java 21 (Temurin)',
  nodeVersion: 'Node.js 20',
  androidTarget: 'Android Gradle Wrapper',
  outputArtifactName: 'android-apk-{run_number}',
};

export const RAW_WORKFLOW_YML = `name: Build Android APK (Capacitor)

# Workflow otomatis build APK Android untuk aplikasi Kasir (com.srcmasngud.kasir)
# Dilengkapi penangkapan error presisi (What went wrong) & auto-license Android SDK

on:
  push:
    branches:
      - main
      - master
    paths-ignore:
      - 'README.md'
      - '.gitignore'
      - 'LICENSE'
  pull_request:
    branches:
      - main
      - master
  workflow_dispatch:
    inputs:
      build_type:
        description: 'Pilih tipe APK yang akan di-build (debug, release, atau both)'
        required: true
        default: 'debug'
        type: choice
        options:
          - debug
          - release
          - both

jobs:
  build:
    name: Build Android APK
    runs-on: ubuntu-latest

    steps:
      - name: 1. Checkout Repository
        uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - name: 1b. Deteksi & Selaraskan Struktur Folder Proyek
        run: |
          echo "=== 1. CEK STRUKTUR REPOSITORY AWAL ==="
          ls -la

          # Ekstrak file zip jika ada
          ZIP_COUNT=$(find . -maxdepth 3 -name "*.zip" | wc -l)
          if [ "$ZIP_COUNT" -gt 0 ]; then
            echo "Ditemukan file .zip di repository, mengekstrak..."
            find . -maxdepth 3 -name "*.zip" -exec unzip -o {} \\;
          fi

          # Cari package.json jika tidak ada di root
          if [ ! -f "package.json" ]; then
            PKG_PATH=$(find . -name "package.json" -not -path "*/node_modules/*" | head -n 1)
            if [ -n "$PKG_PATH" ]; then
              SUBDIR=$(dirname "$PKG_PATH")
              echo "Proyek web ditemukan di: $SUBDIR"
              if [ "$SUBDIR" != "." ]; then
                echo "Menyalin file dari $SUBDIR ke root..."
                shopt -s dotglob
                cp -rn "$SUBDIR"/* . || cp -r "$SUBDIR"/* . || true
                shopt -u dotglob
              fi
            fi
          fi

          # Cari folder android jika belum ada di root
          if [ ! -d "android" ]; then
            echo "Folder android belum ada di root, mencari..."
            ANDROID_PATH=$(find . -type d -name "android" -not -path "*/node_modules/*" -not -path "./android" | head -n 1)
            if [ -n "$ANDROID_PATH" ]; then
              echo "Menyalin folder android dari $ANDROID_PATH ke ./android..."
              cp -r "$ANDROID_PATH" ./android || true
            fi
          fi

          echo "=== STRUKTUR DIREKTORI AKHIR ==="
          ls -la

      - name: 2. Set up Node.js
        uses: actions/setup-node@v4
        with:
          node-version: 20

      - name: 3. Set up Java JDK 21 (Diperlukan untuk Capacitor 7)
        uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '21'

      - name: 4. Set up Android SDK
        uses: android-actions/setup-android@v3

      - name: 4b. Terima Lisensi Android SDK & Build-Tools
        run: |
          export ANDROID_HOME=\${ANDROID_HOME:-/usr/local/lib/android/sdk}
          export PATH=$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/tools/bin:$ANDROID_HOME/platform-tools:$PATH
          echo "Menyetujui lisensi SDK..."
          yes | sdkmanager --licenses || true
          sdkmanager "platforms;android-34" "build-tools;34.0.0" || true

      - name: 5. Install Dependencies Node.js
        run: |
          if [ -f "package.json" ]; then
            echo "Menginstall dependensi project..."
            npm install --legacy-peer-deps
            npm install react-is --legacy-peer-deps || true
          else
            echo "Tidak ada package.json, melewati step install npm..."
          fi

      - name: 6. Build Web Assets (Vite)
        run: |
          if [ -f "package.json" ]; then
            echo "Membangun web assets dengan Vite..."
            npm run build || {
              echo "Peringatan: Build Vite mengalami kendala. Memeriksa aset bawaan Android..."
              if [ -f "android/app/src/main/assets/public/index.html" ]; then
                echo "Aset web Android sudah tersedia lengkap di android/app/src/main/assets/public. Melanjutkan..."
                mkdir -p dist
                cp -r android/app/src/main/assets/public/* dist/ || true
              fi
            }
          else
            echo "Tidak ada package.json, melewati step build web..."
          fi

      - name: 7. Sinkronisasi Capacitor dengan Android
        run: |
          if [ -f "package.json" ] && [ -d "android" ]; then
            echo "Sinkronisasi Capacitor ke folder android..."
            npx cap sync android || true
          else
            echo "Melewati sinkronisasi Capacitor..."
          fi

      - name: 8. Konfigurasi Gradle Properties & Permissions
        run: |
          echo "Mengoptimalkan gradle.properties..."
          GRADLE_PROP=$(find . -name "gradle.properties" | head -n 1)
          if [ -n "$GRADLE_PROP" ]; then
            echo "" >> "$GRADLE_PROP"
            echo "android.useAndroidX=true" >> "$GRADLE_PROP"
            echo "android.enableJetifier=true" >> "$GRADLE_PROP"
            echo "org.gradle.jvmargs=-Xmx3072m -XX:MaxMetaspaceSize=768m -Dfile.encoding=UTF-8" >> "$GRADLE_PROP"
          fi

          if [ -d "android/app" ] && [ ! -f "android/app/google-services.json" ]; then
            echo "Membuat google-services.json default untuk com.srcmasngud.kasir..."
            echo '{"project_info":{"project_number":"386138592370","project_id":"kasir-srcmasngud","storage_bucket":"kasir-srcmasngud.appspot.com"},"client":[{"client_info":{"mobilesdk_app_id":"1:386138592370:android:a1b2c3d4e5f6","android_client_info":{"package_name":"com.srcmasngud.kasir"}},"oauth_client":[],"api_key":[{"current_key":"AIzaSyDummyKeyForBuildVerification1234567"}],"services":{"appinvite_service":{"other_platform_oauth_client":[]}}}],"configuration_version":"1"}' > android/app/google-services.json
          fi

          find . -name "gradlew" -exec chmod +x {} \\;

      - name: 9. Build Debug APK
        if: github.event_name != 'workflow_dispatch' || github.event.inputs.build_type == 'debug' || github.event.inputs.build_type == 'both'
        run: |
          GRADLEW_FILE=$(find . -name "gradlew" | head -n 1)
          if [ -z "$GRADLEW_FILE" ]; then
            echo "ERROR: File gradlew tidak ditemukan di repository!"
            exit 1
          fi
          GRADLE_DIR=$(dirname "$GRADLEW_FILE")
          echo "Menjalankan build Debug APK di: $GRADLE_DIR"
          cd "$GRADLE_DIR"
          chmod +x ./gradlew

          set +e
          ./gradlew assembleDebug -x lint -x test --no-daemon --stacktrace > gradle_build.log 2>&1
          BUILD_EXIT=$?

          if [ $BUILD_EXIT -ne 0 ]; then
            echo ""
            echo "================================================================="
            echo "❌ PENYEBAB PASTI ERROR GRADLE (WHAT WENT WRONG):"
            echo "================================================================="
            sed -n '/\\* What went wrong:/,/\\* Try:/p' gradle_build.log
            echo "-----------------------------------------------------------------"
            grep -E "(> Task .* FAILED|error:|failed|Could not resolve|is missing|unsupported)" gradle_build.log | grep -v "org.gradle" | head -n 35 || true
            echo "================================================================="
            tail -n 60 gradle_build.log
            exit $BUILD_EXIT
          else
            echo "✅ Build Gradle Berhasil! File APK telah dibuat."
          fi

      - name: 10. Build Release APK
        if: github.event_name == 'workflow_dispatch' && (github.event.inputs.build_type == 'release' || github.event.inputs.build_type == 'both')
        run: |
          GRADLEW_FILE=$(find . -name "gradlew" | head -n 1)
          if [ -z "$GRADLEW_FILE" ]; then
            echo "ERROR: File gradlew tidak ditemukan di repository!"
            exit 1
          fi
          GRADLE_DIR=$(dirname "$GRADLEW_FILE")
          echo "Menjalankan build Release APK di: $GRADLE_DIR"
          cd "$GRADLE_DIR"
          chmod +x ./gradlew

          set +e
          ./gradlew assembleRelease -x lint -x test --no-daemon --stacktrace > gradle_release.log 2>&1
          BUILD_EXIT=$?

          if [ $BUILD_EXIT -ne 0 ]; then
            echo ""
            echo "================================================================="
            echo "❌ PENYEBAB PASTI ERROR GRADLE RELEASE:"
            echo "================================================================="
            sed -n '/\\* What went wrong:/,/\\* Try:/p' gradle_release.log
            echo "-----------------------------------------------------------------"
            tail -n 60 gradle_release.log
            exit $BUILD_EXIT
          else
            echo "✅ Build Release Berhasil! File APK Release telah dibuat."
          fi

      - name: 11. Tandatangani Release APK (Jika Keystore Disediakan)
        if: github.event.inputs.build_type == 'release' || github.event.inputs.build_type == 'both'
        env:
          ANDROID_KEYSTORE_BASE64: \${{ secrets.ANDROID_KEYSTORE_BASE64 }}
          KEYSTORE_PASSWORD: \${{ secrets.KEYSTORE_PASSWORD }}
          KEY_ALIAS: \${{ secrets.KEY_ALIAS }}
          KEY_PASSWORD: \${{ secrets.KEY_PASSWORD }}
        run: |
          if [ -z "$ANDROID_KEYSTORE_BASE64" ]; then
            echo "ANDROID_KEYSTORE_BASE64 tidak disediakan di Secrets. Melewati proses penandatanganan."
            exit 0
          fi
          echo "Mendekode Android Keystore..."
          echo "$ANDROID_KEYSTORE_BASE64" | base64 --decode > release.keystore
          
          RELEASE_APK=$(find . -name "*release*.apk" -not -path "*/build-output/*" | head -n 1)
          if [ -f "$RELEASE_APK" ]; then
            echo "Menandatangani APK $RELEASE_APK..."
            jarsigner -verbose -sigalg SHA256withRSA -digestalg SHA-256 \\
              -keystore release.keystore \\
              -storepass "$KEYSTORE_PASSWORD" \\
              -keypass "$KEY_PASSWORD" \\
              "$RELEASE_APK" "$KEY_ALIAS"
          fi

      - name: 12. Kumpulkan File APK ke Folder Output
        run: |
          mkdir -p build-output
          echo "Mencari semua file .apk yang berhasil di-build..."
          find . -type f -name "*.apk" -not -path "*/build-output/*" -exec cp -v {} build-output/ \\;
          echo "Daftar file APK yang tersedia:"
          ls -la build-output/
          if [ $(ls -1 build-output/*.apk 2>/dev/null | wc -l) -eq 0 ]; then
            echo "ERROR: Tidak ada file APK yang berhasil dibuat!"
            exit 1
          fi

      - name: 13. Upload APK sebagai GitHub Actions Artifact
        uses: actions/upload-artifact@v4
        with:
          name: android-apk-\${{ github.run_number }}
          path: build-output/*.apk
          retention-days: 30

      - name: 14. Publikasikan Release di GitHub (Saat Git Tag dibuat)
        if: startsWith(github.ref, 'refs/tags/v')
        uses: softprops/action-gh-release@v2
        with:
          files: build-output/*.apk
          name: Release \${{ github.ref_name }}
          draft: false
          prerelease: false
          generate_release_notes: true
        env:
          GITHUB_TOKEN: \${{ secrets.GITHUB_TOKEN }}
`;

export const PIPELINE_STEPS: PipelineStep[] = [
  {
    id: 'checkout',
    number: 1,
    title: 'Checkout Repository',
    description: 'Mengunduh seluruh source code proyek dari GitHub repository ke runner Ubuntu.',
    commandOrAction: 'actions/checkout@v4',
    category: 'setup',
    status: 'mandatory',
  },
  {
    id: 'auto-flatten',
    number: 2,
    title: 'Deteksi & Ekstrak Proyek Otomatis',
    description: 'Mendeteksi apakah package.json/android ada di subfolder atau dalam file .zip, lalu menyelaraskannya ke root secara otomatis.',
    commandOrAction: 'unzip *.zip & auto-flatten subdir',
    category: 'setup',
    status: 'mandatory',
  },
  {
    id: 'setup-node',
    number: 3,
    title: 'Setup Node.js 20',
    description: 'Menyiapkan runtime Node.js 20 tanpa ketergantungan cache yang kaku agar tidak error.',
    commandOrAction: 'actions/setup-node@v4 (node-version: 20)',
    category: 'setup',
    status: 'mandatory',
  },
  {
    id: 'setup-java',
    number: 4,
    title: 'Setup Java JDK 21',
    description: 'Mengonfigurasi JDK 21 (Eclipse Temurin) yang dibutuhkan oleh Capacitor 7 dan Android Gradle Plugin modern.',
    commandOrAction: 'actions/setup-java@v4 (java-version: 21)',
    category: 'android',
    status: 'mandatory',
  },
  {
    id: 'setup-android-sdk',
    number: 5,
    title: 'Setup Android SDK & Command-line Tools',
    description: 'Memastikan Android SDK platform tools, build-tools, dan lisensi Google telah disetujui.',
    commandOrAction: 'android-actions/setup-android@v3',
    category: 'android',
    status: 'mandatory',
  },
  {
    id: 'install-deps',
    number: 6,
    title: 'Install Dependensi Proyek (Kondisional)',
    description: 'Jika ada package.json, jalankan npm install. Jika tidak ada, dilewati agar langsung build Gradle Android.',
    commandOrAction: 'if [ -f package.json ]; then npm install; fi',
    category: 'build',
    status: 'mandatory',
  },
  {
    id: 'build-web',
    number: 7,
    title: 'Kompilasi Web Assets (Kondisional)',
    description: 'Membangun aplikasi web Vite jika package.json tersedia. Melewatinya jika aset Android sudah siap.',
    commandOrAction: 'if [ -f package.json ]; then npm run build; fi',
    category: 'build',
    status: 'mandatory',
  },
  {
    id: 'cap-sync',
    number: 8,
    title: 'Sinkronisasi Capacitor ke Android',
    description: 'Menyinkronkan aset web ke Capacitor Android jika package.json & folder android tersedia.',
    commandOrAction: 'npx cap sync android',
    category: 'android',
    status: 'mandatory',
  },
  {
    id: 'chmod-gradlew',
    number: 9,
    title: 'Izin Eksekusi Gradle Wrapper',
    description: 'Mencari file gradlew di seluruh direktori dan memberikan izin eksekusi chmod +x.',
    commandOrAction: 'find . -name "gradlew" -exec chmod +x {} \\;',
    category: 'android',
    status: 'mandatory',
  },
  {
    id: 'build-apk-debug',
    number: 10,
    title: 'Build Debug APK (Auto-locate Gradle)',
    description: 'Otomatis menemukan direktori letak gradlew dan menjalankan ./gradlew assembleDebug.',
    commandOrAction: 'cd $GRADLE_DIR && ./gradlew assembleDebug',
    category: 'android',
    status: 'mandatory',
  },
  {
    id: 'build-apk-release',
    number: 11,
    title: 'Build Release APK (Opsional)',
    description: 'Menghasilkan APK Release yang dioptimasi jika dipilih pada menu dispatch.',
    commandOrAction: './gradlew assembleRelease --stacktrace',
    category: 'android',
    status: 'conditional',
  },
  {
    id: 'sign-apk',
    number: 12,
    title: 'Tandatangani APK Release (Keystore)',
    description: 'Menandatangani file APK menggunakan Secret GitHub Actions jika rahasia Keystore diatur.',
    commandOrAction: 'jarsigner -keystore release.keystore ...',
    category: 'android',
    status: 'optional',
  },
  {
    id: 'collect-output',
    number: 13,
    title: 'Kumpulkan File APK ke Folder Output',
    description: 'Mencari semua file .apk hasil build dan menyalinnya ke folder build-output/.',
    commandOrAction: 'find . -name "*.apk" -exec cp {} build-output/ \\;',
    category: 'deploy',
    status: 'mandatory',
  },
  {
    id: 'upload-artifact',
    number: 14,
    title: 'Upload APK Artifact',
    description: 'Mengunggah APK ke GitHub Actions Summary sehingga dapat langsung diunduh dari browser.',
    commandOrAction: 'actions/upload-artifact@v4',
    category: 'deploy',
    status: 'mandatory',
  },
];
