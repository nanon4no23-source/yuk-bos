import React, { useState, useMemo } from 'react';
import { 
  Package, 
  PlusCircle, 
  Search, 
  Edit3, 
  Trash2, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle, 
  RotateCcw, 
  Save, 
  Barcode, 
  TrendingUp, 
  Plus, 
  Minus,
  Sparkles,
  Layers,
  Filter
} from 'lucide-react';
import { Product } from '../types';
import { CATEGORIES, INITIAL_PRODUCTS } from '../data/sampleProducts';

interface StokBarangViewProps {
  products: Product[];
  onUpdateProducts: (products: Product[]) => void;
  isLandscape?: boolean;
}

export const StokBarangView: React.FC<StokBarangViewProps> = ({
  products,
  onUpdateProducts,
  isLandscape = false
}) => {
  // Form state (Left Column)
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    barcode: '',
    category: 'Sembako',
    unit: 'pcs',
    costPrice: '',
    sellingPrice: '',
    stock: '',
    minStockAlert: '5'
  });
  const [formSuccessMessage, setFormSuccessMessage] = useState<string | null>(null);
  const [formErrorMessage, setFormErrorMessage] = useState<string | null>(null);

  // Filter & Search state (Right Column)
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Semua Kategori');
  const [filterStockStatus, setFilterStockStatus] = useState<'all' | 'low' | 'out'>('all');

  // Calculation of profit margin for form
  const numCost = Number(formData.costPrice) || 0;
  const numSell = Number(formData.sellingPrice) || 0;
  const profit = numSell - numCost;
  const profitMarginPercent = numCost > 0 ? Math.round((profit / numCost) * 100) : 0;

  // Filtered Products for Right Column
  const filteredProducts = useMemo(() => {
    return products.filter((item) => {
      const matchQuery = 
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.barcode.toLowerCase().includes(searchQuery.toLowerCase());
      const matchCat = 
        selectedCategory === 'Semua Kategori' || item.category === selectedCategory;
      
      let matchStatus = true;
      if (filterStockStatus === 'low') {
        matchStatus = item.stock <= (item.minStockAlert || 5) && item.stock > 0;
      } else if (filterStockStatus === 'out') {
        matchStatus = item.stock === 0;
      }

      return matchQuery && matchCat && matchStatus;
    });
  }, [products, searchQuery, selectedCategory, filterStockStatus]);

  // Inventory stats
  const totalSku = products.length;
  const lowStockCount = products.filter((p) => p.stock <= (p.minStockAlert || 5) && p.stock > 0).length;
  const outOfStockCount = products.filter((p) => p.stock === 0).length;
  const totalAssetValue = products.reduce((acc, p) => acc + (p.costPrice * p.stock), 0);

  // Generate random barcode
  const handleGenerateBarcode = () => {
    const randomEan = '899' + Math.floor(1000000000 + Math.random() * 9000000000);
    setFormData((prev) => ({ ...prev, barcode: randomEan }));
  };

  // Populate form for edit
  const handleStartEdit = (product: Product) => {
    setEditingId(product.id);
    setFormData({
      name: product.name,
      barcode: product.barcode,
      category: product.category,
      unit: product.unit || 'pcs',
      costPrice: product.costPrice.toString(),
      sellingPrice: product.sellingPrice.toString(),
      stock: product.stock.toString(),
      minStockAlert: (product.minStockAlert || 5).toString()
    });
    setFormErrorMessage(null);
    setFormSuccessMessage(null);
    // Scroll smoothly to form if on mobile
    const formEl = document.getElementById('kolom-kiri-tambah-barang');
    if (formEl && window.innerWidth < 768) {
      formEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Cancel edit / reset form
  const handleResetForm = () => {
    setEditingId(null);
    setFormData({
      name: '',
      barcode: '',
      category: 'Sembako',
      unit: 'pcs',
      costPrice: '',
      sellingPrice: '',
      stock: '',
      minStockAlert: '5'
    });
    setFormErrorMessage(null);
    setFormSuccessMessage(null);
  };

  // Submit Add / Edit
  const handleSubmitProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      setFormErrorMessage('Nama barang wajib diisi.');
      return;
    }

    const sellingPrice = Number(formData.sellingPrice) || 0;
    if (sellingPrice <= 0) {
      setFormErrorMessage('Harga jual harus lebih besar dari Rp 0.');
      return;
    }

    const costPrice = Number(formData.costPrice) || 0;
    const stock = Math.max(0, Number(formData.stock) || 0);
    const minAlert = Math.max(1, Number(formData.minStockAlert) || 5);
    const barcode = formData.barcode.trim() || ('899' + Date.now().toString().slice(-10));

    if (editingId) {
      // Update existing
      const updated = products.map((p) => {
        if (p.id === editingId) {
          return {
            ...p,
            name: formData.name.trim(),
            barcode,
            category: formData.category,
            unit: formData.unit.trim() || 'pcs',
            costPrice,
            sellingPrice,
            stock,
            minStockAlert: minAlert
          };
        }
        return p;
      });
      onUpdateProducts(updated);
      setFormSuccessMessage(`Data produk "${formData.name}" berhasil diperbarui.`);
      handleResetForm();
    } else {
      // Add new
      const newProduct: Product = {
        id: 'prod-' + Date.now(),
        name: formData.name.trim(),
        barcode,
        category: formData.category,
        unit: formData.unit.trim() || 'pcs',
        costPrice,
        sellingPrice,
        stock,
        minStockAlert: minAlert
      };
      onUpdateProducts([newProduct, ...products]);
      setFormSuccessMessage(`Barang "${newProduct.name}" berhasil ditambahkan.`);
      handleResetForm();
    }

    setTimeout(() => {
      setFormSuccessMessage(null);
    }, 3500);
  };

  // Quick adjust stock
  const handleQuickAdjustStock = (productId: string, delta: number) => {
    const updated = products.map((p) => {
      if (p.id === productId) {
        return {
          ...p,
          stock: Math.max(0, p.stock + delta)
        };
      }
      return p;
    });
    onUpdateProducts(updated);
  };

  // Delete product
  const handleDeleteProduct = (productId: string, name: string) => {
    if (window.confirm(`Hapus barang "${name}" dari daftar inventaris?`)) {
      onUpdateProducts(products.filter((p) => p.id !== productId));
      if (editingId === productId) {
        handleResetForm();
      }
    }
  };

  // Reset to default sample
  const handleResetToDefault = () => {
    if (window.confirm('Muat ulang 12 data barang bawaan toko kelontong?')) {
      onUpdateProducts(INITIAL_PRODUCTS);
      handleResetForm();
    }
  };

  const formatRupiah = (val: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0
    }).format(val);
  };

  const isEffectiveLandscape = isLandscape || (typeof window !== 'undefined' ? (window.innerWidth > window.innerHeight || window.innerWidth >= 768) : true);

  return (
    <div className="space-y-4">
      {/* Visual Indicator of 2-Column Mode */}
      <div className={`${isEffectiveLandscape ? 'flex' : 'hidden landscape:flex md:flex'} items-center justify-between px-4 py-2 bg-indigo-50 border border-indigo-200 rounded-xl text-xs text-indigo-900`}>
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-indigo-500 animate-pulse"></span>
          <span className="font-bold">Mode 2 Kolom Aktif</span>
          <span className="text-slate-600 font-medium">• Kolom Kiri: Tambah Barang | Kolom Kanan: Stok Barang</span>
        </div>
        <div className="font-mono text-indigo-700 font-medium text-[11px] sm:text-xs">
          {totalSku} Total SKU Terdaftar
        </div>
      </div>

      {/* Grid: 2 Columns on Landscape / Large screen */}
      <div className={`grid gap-5 items-start stok-landscape-grid ${
        isEffectiveLandscape
          ? 'grid-cols-12'
          : 'grid-cols-1 landscape:grid-cols-12 md:grid-cols-12'
      }`}>

        {/* ========================================================= */}
        {/* SEBELAH KIRI: FORM TAMBAH BARANG / EDIT BARANG             */}
        {/* ========================================================= */}
        <section 
          id="kolom-kiri-tambah-barang"
          className={`${
            isEffectiveLandscape
              ? 'col-span-5 sticky top-20'
              : 'col-span-1 landscape:col-span-5 md:col-span-5 landscape:sticky landscape:top-20 md:sticky md:top-20'
          } stok-col-kiri-tambah space-y-4`}
        >
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 space-y-4">
            {/* Header Form */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <div className={`p-1.5 rounded-lg ${editingId ? 'bg-amber-100 text-amber-700' : 'bg-indigo-100 text-indigo-700'}`}>
                  {editingId ? <Edit3 className="w-4 h-4" /> : <PlusCircle className="w-4 h-4" />}
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-md bg-indigo-100 text-indigo-800 uppercase tracking-wider">
                      Kolom Kiri
                    </span>
                    <h2 className="font-bold text-slate-800 text-sm">
                      {editingId ? 'Edit Data Barang' : 'Tambah Barang'}
                    </h2>
                  </div>
                  <p className="text-[11px] text-slate-500">
                    {editingId ? 'Ubah rincian produk terpilih' : 'Form input stok barang baru'}
                  </p>
                </div>
              </div>

              {editingId && (
                <button
                  type="button"
                  onClick={handleResetForm}
                  className="text-xs text-slate-500 hover:text-slate-700 bg-slate-100 px-2 py-1 rounded-md"
                >
                  Batal Edit
                </button>
              )}
            </div>

            {/* Notification Messages */}
            {formSuccessMessage && (
              <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{formSuccessMessage}</span>
              </div>
            )}
            {formErrorMessage && (
              <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
                <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{formErrorMessage}</span>
              </div>
            )}

            {/* Input Form */}
            <form onSubmit={handleSubmitProduct} className="space-y-3">
              {/* 1. Nama Barang */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Nama Barang <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Misal: Minyak Goreng Bimoli 2L"
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:outline-hidden"
                />
              </div>

              {/* 2. Barcode & Generate Button */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-slate-700">
                    Barcode / SKU
                  </label>
                  <button
                    type="button"
                    onClick={handleGenerateBarcode}
                    className="text-[11px] text-indigo-600 hover:text-indigo-800 font-medium inline-flex items-center gap-1"
                  >
                    <Barcode className="w-3 h-3" />
                    <span>Acak Kode</span>
                  </button>
                </div>
                <input
                  type="text"
                  value={formData.barcode}
                  onChange={(e) => setFormData({ ...formData, barcode: e.target.value })}
                  placeholder="Kode barcode produk..."
                  className="w-full px-3 py-2 text-xs font-mono bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:outline-hidden"
                />
              </div>

              {/* 3. Kategori & Satuan */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Kategori
                  </label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="w-full px-2.5 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:outline-hidden"
                  >
                    {CATEGORIES.filter((c) => c !== 'Semua Kategori').map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Satuan
                  </label>
                  <input
                    type="text"
                    value={formData.unit}
                    onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
                    placeholder="pcs / kg / botol"
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:outline-hidden"
                  />
                </div>
              </div>

              {/* 4. Harga Beli & Harga Jual */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Harga Modal (Rp)
                  </label>
                  <input
                    type="number"
                    value={formData.costPrice}
                    onChange={(e) => setFormData({ ...formData, costPrice: e.target.value })}
                    placeholder="0"
                    min="0"
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Harga Jual (Rp) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="number"
                    required
                    value={formData.sellingPrice}
                    onChange={(e) => setFormData({ ...formData, sellingPrice: e.target.value })}
                    placeholder="0"
                    min="1"
                    className="w-full px-3 py-2 text-xs font-bold text-emerald-700 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:outline-hidden"
                  />
                </div>
              </div>

              {/* Estimasi Keuntungan Realtime */}
              {numSell > 0 && numCost > 0 && (
                <div className="p-2.5 rounded-lg bg-emerald-50/70 border border-emerald-200 flex items-center justify-between text-xs text-emerald-800">
                  <span className="flex items-center gap-1">
                    <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Margin Untung:</span>
                  </span>
                  <span className="font-bold">
                    {formatRupiah(profit)} ({profitMarginPercent}%)
                  </span>
                </div>
              )}

              {/* 5. Jumlah Stok & Minimal Alert */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Jumlah Stok
                  </label>
                  <input
                    type="number"
                    value={formData.stock}
                    onChange={(e) => setFormData({ ...formData, stock: e.target.value })}
                    placeholder="0"
                    min="0"
                    className="w-full px-3 py-2 text-xs font-bold bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Batas Peringatan
                  </label>
                  <input
                    type="number"
                    value={formData.minStockAlert}
                    onChange={(e) => setFormData({ ...formData, minStockAlert: e.target.value })}
                    placeholder="5"
                    min="1"
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:bg-white focus:outline-hidden"
                  />
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex items-center gap-2">
                <button
                  type="submit"
                  className={`flex-1 py-2.5 px-4 rounded-xl text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-xs cursor-pointer ${
                    editingId 
                      ? 'bg-amber-600 hover:bg-amber-700' 
                      : 'bg-indigo-600 hover:bg-indigo-700'
                  }`}
                >
                  <Save className="w-4 h-4" />
                  <span>{editingId ? 'Simpan Perubahan' : 'Tambah ke Stok'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleResetForm}
                  className="px-3 py-2.5 rounded-xl border border-slate-200 hover:bg-slate-100 text-slate-600 text-xs font-medium transition-colors"
                >
                  Reset
                </button>
              </div>
            </form>
          </div>
        </section>


        {/* ========================================================= */}
        {/* SEBELAH KANAN: KOLOM DAFTAR STOK BARANG                    */}
        {/* ========================================================= */}
        <section 
          id="kolom-kanan-daftar-stok"
          className={`${
            isEffectiveLandscape
              ? 'col-span-7'
              : 'col-span-1 landscape:col-span-7 md:col-span-7'
          } stok-col-kanan-daftar space-y-4`}
        >
          {/* Summary Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-[11px] text-slate-500 font-medium">Total Barang</span>
              <div className="text-lg font-bold text-slate-900 mt-0.5">{totalSku} SKU</div>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-[11px] text-amber-600 font-medium">Stok Menipis</span>
              <div className="text-lg font-bold text-amber-700 mt-0.5">{lowStockCount} Produk</div>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-[11px] text-rose-600 font-medium">Stok Habis</span>
              <div className="text-lg font-bold text-rose-700 mt-0.5">{outOfStockCount} Produk</div>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-[11px] text-emerald-600 font-medium">Estimasi Nilai</span>
              <div className="text-xs font-bold text-emerald-700 mt-1 truncate">
                {formatRupiah(totalAssetValue)}
              </div>
            </div>
          </div>

          {/* Main Stock Table / List Box */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            {/* Filter & Search Bar */}
            <div className="p-3.5 bg-slate-50/80 border-b border-slate-200 space-y-2.5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 bg-indigo-100 text-indigo-700 rounded-lg">
                    <Package className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-md bg-emerald-100 text-emerald-800 uppercase tracking-wider">
                        Kolom Kanan
                      </span>
                      <h3 className="font-bold text-slate-800 text-sm">Stok Barang</h3>
                    </div>
                    <p className="text-[11px] text-slate-500">
                      Menampilkan {filteredProducts.length} dari {products.length} barang inventaris
                    </p>
                  </div>
                </div>

                {/* Search Box */}
                <div className="relative w-full sm:w-64">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Cari nama atau barcode..."
                    className="w-full pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  />
                </div>
              </div>

              {/* Status Filter Buttons & Categories */}
              <div className="flex items-center justify-between gap-2 flex-wrap text-xs">
                <div className="flex items-center gap-1 overflow-x-auto no-scrollbar py-0.5">
                  <button
                    type="button"
                    onClick={() => setFilterStockStatus('all')}
                    className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors ${
                      filterStockStatus === 'all'
                        ? 'bg-indigo-600 text-white shadow-2xs'
                        : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    Semua ({products.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setFilterStockStatus('low')}
                    className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors ${
                      filterStockStatus === 'low'
                        ? 'bg-amber-600 text-white shadow-2xs'
                        : 'bg-white border border-slate-200 text-amber-700 hover:bg-amber-50'
                    }`}
                  >
                    Menipis ({lowStockCount})
                  </button>
                  <button
                    type="button"
                    onClick={() => setFilterStockStatus('out')}
                    className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors ${
                      filterStockStatus === 'out'
                        ? 'bg-rose-600 text-white shadow-2xs'
                        : 'bg-white border border-slate-200 text-rose-700 hover:bg-rose-50'
                    }`}
                  >
                    Habis ({outOfStockCount})
                  </button>
                </div>

                <button
                  type="button"
                  onClick={handleResetToDefault}
                  className="inline-flex items-center gap-1 text-[11px] text-slate-500 hover:text-indigo-600 hover:underline"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset Data Demo</span>
                </button>
              </div>
            </div>

            {/* List of Products */}
            <div className="divide-y divide-slate-100 max-h-[480px] overflow-y-auto">
              {filteredProducts.length === 0 ? (
                <div className="p-8 text-center space-y-2">
                  <Package className="w-10 h-10 text-slate-300 mx-auto" />
                  <p className="font-semibold text-sm text-slate-700">Tidak ada barang ditemukan</p>
                  <p className="text-xs text-slate-500">
                    Coba ubah kata kunci pencarian atau tambah barang baru lewat kolom di sebelah kiri.
                  </p>
                </div>
              ) : (
                filteredProducts.map((item) => {
                  const isLow = item.stock <= (item.minStockAlert || 5) && item.stock > 0;
                  const isOut = item.stock === 0;

                  return (
                    <div
                      key={item.id}
                      className={`p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-colors ${
                        editingId === item.id ? 'bg-indigo-50/50' : 'hover:bg-slate-50/70'
                      }`}
                    >
                      {/* Product Details */}
                      <div className="min-w-0 flex-1 space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-xs sm:text-sm text-slate-800">
                            {item.name}
                          </span>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            isOut
                              ? 'bg-rose-100 text-rose-700 border border-rose-200'
                              : isLow
                              ? 'bg-amber-100 text-amber-800 border border-amber-200'
                              : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                          }`}>
                            {isOut ? 'Habis' : isLow ? 'Stok Menipis' : 'Stok Aman'}
                          </span>
                        </div>

                        <div className="flex items-center gap-2 text-[11px] text-slate-500 font-mono flex-wrap">
                          <span>{item.barcode}</span>
                          <span>•</span>
                          <span className="text-slate-600 font-sans">{item.category}</span>
                          <span>•</span>
                          <span className="text-emerald-700 font-bold font-sans">
                            Jual: {formatRupiah(item.sellingPrice)}
                          </span>
                          {item.costPrice > 0 && (
                            <>
                              <span>•</span>
                              <span className="text-slate-500 font-sans">
                                Modal: {formatRupiah(item.costPrice)}
                              </span>
                            </>
                          )}
                        </div>
                      </div>

                      {/* Stock Adjustment & Actions */}
                      <div className="flex items-center gap-3 shrink-0 self-end sm:self-center">
                        {/* Quick Stock Counter Buttons */}
                        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
                          <button
                            type="button"
                            onClick={() => handleQuickAdjustStock(item.id, -1)}
                            disabled={item.stock <= 0}
                            className="w-6 h-6 rounded bg-white hover:bg-slate-200 text-slate-700 flex items-center justify-center transition-colors disabled:opacity-40"
                            title="Kurangi stok 1"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="w-10 text-center font-bold text-xs text-slate-800 font-mono">
                            {item.stock} {item.unit || 'pcs'}
                          </span>
                          <button
                            type="button"
                            onClick={() => handleQuickAdjustStock(item.id, 1)}
                            className="w-6 h-6 rounded bg-white hover:bg-slate-200 text-slate-700 flex items-center justify-center transition-colors"
                            title="Tambah stok 1"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        {/* Edit & Delete Action Buttons */}
                        <button
                          type="button"
                          onClick={() => handleStartEdit(item)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 transition-colors"
                          title="Edit produk di kolom kiri"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>

                        <button
                          type="button"
                          onClick={() => handleDeleteProduct(item.id, item.name)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                          title="Hapus barang"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </section>

      </div>
    </div>
  );
};
