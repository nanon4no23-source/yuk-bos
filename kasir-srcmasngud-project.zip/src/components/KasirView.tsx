import React, { useState, useMemo } from 'react';
import { 
  ShoppingCart, 
  Trash2, 
  Plus, 
  Minus, 
  Search, 
  CreditCard, 
  Banknote, 
  QrCode, 
  Check, 
  AlertCircle,
  RotateCcw,
  Sparkles,
  ShoppingBag,
  User,
  Percent,
  ReceiptText
} from 'lucide-react';
import { Product, CartItem, Transaction } from '../types';
import { CATEGORIES } from '../data/sampleProducts';

interface KasirViewProps {
  products: Product[];
  onUpdateProducts: (products: Product[]) => void;
  onCompleteTransaction: (transaction: Transaction) => void;
  isLandscape?: boolean;
}

export const KasirView: React.FC<KasirViewProps> = ({
  products,
  onUpdateProducts,
  onCompleteTransaction,
  isLandscape = false
}) => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Semua Kategori');
  
  // Payment states
  const [paymentMethod, setPaymentMethod] = useState<'tunai' | 'qris' | 'debit' | 'transfer'>('tunai');
  const [cashGiven, setCashGiven] = useState<string>('');
  const [discountAmount, setDiscountAmount] = useState<number>(0);
  const [taxEnabled, setTaxEnabled] = useState<boolean>(false);
  const [customerName, setCustomerName] = useState<string>('');
  const [paymentError, setPaymentError] = useState<string | null>(null);

  // Filter products for quick selection
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const matchQuery = 
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.barcode.toLowerCase().includes(searchQuery.toLowerCase());
      const matchCat = 
        selectedCategory === 'Semua Kategori' || p.category === selectedCategory;
      return matchQuery && matchCat;
    });
  }, [products, searchQuery, selectedCategory]);

  // Cart calculations
  const subtotal = useMemo(() => {
    return cart.reduce((acc, item) => acc + item.product.sellingPrice * item.quantity, 0);
  }, [cart]);

  const taxAmount = useMemo(() => {
    if (!taxEnabled) return 0;
    return Math.round((subtotal - discountAmount) * 0.11);
  }, [subtotal, discountAmount, taxEnabled]);

  const grandTotal = useMemo(() => {
    const total = subtotal - discountAmount + taxAmount;
    return Math.max(0, total);
  }, [subtotal, discountAmount, taxAmount]);

  const numericCash = Number(cashGiven) || 0;
  const changeAmount = Math.max(0, numericCash - grandTotal);
  const isCashSufficient = paymentMethod !== 'tunai' || numericCash >= grandTotal;

  // Add to cart
  const handleAddToCart = (product: Product) => {
    if (product.stock <= 0) return;

    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        if (existing.quantity >= product.stock) return prev;
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      } else {
        return [...prev, { product, quantity: 1, discount: 0 }];
      }
    });
  };

  // Update quantity
  const handleUpdateQty = (productId: string, delta: number) => {
    setCart((prev) => {
      return prev
        .map((item) => {
          if (item.product.id === productId) {
            const nextQty = item.quantity + delta;
            if (nextQty <= 0) return null;
            if (nextQty > item.product.stock) return item;
            return { ...item, quantity: nextQty };
          }
          return item;
        })
        .filter(Boolean) as CartItem[];
    });
  };

  // Remove single item
  const handleRemoveItem = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  // Clear all
  const handleClearCart = () => {
    if (cart.length === 0) return;
    setCart([]);
    setCashGiven('');
    setDiscountAmount(0);
    setPaymentError(null);
  };

  // Quick cash buttons
  const setPresetCash = (amount: number) => {
    setCashGiven(amount.toString());
    setPaymentError(null);
  };

  // Submit Transaction
  const handleProcessPayment = () => {
    if (cart.length === 0) {
      setPaymentError('Keranjang belanja masih kosong.');
      return;
    }

    if (paymentMethod === 'tunai' && numericCash < grandTotal) {
      setPaymentError(`Uang tunai kurang Rp ${formatRupiah(grandTotal - numericCash).replace('Rp', '').trim()}`);
      return;
    }

    // Deduct stock from products
    const updatedProducts = products.map((prod) => {
      const cartMatch = cart.find((c) => c.product.id === prod.id);
      if (cartMatch) {
        return {
          ...prod,
          stock: Math.max(0, prod.stock - cartMatch.quantity)
        };
      }
      return prod;
    });
    onUpdateProducts(updatedProducts);

    // Create transaction object
    const newTx: Transaction = {
      id: 'tx-' + Date.now(),
      invoiceNumber: 'INV-' + new Date().toISOString().slice(0, 10).replace(/-/g, '') + '-' + Math.floor(1000 + Math.random() * 9000),
      date: new Date().toLocaleString('id-ID', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }),
      items: [...cart],
      subtotal,
      discount: discountAmount,
      tax: taxAmount,
      total: grandTotal,
      paymentMethod,
      cashAmount: paymentMethod === 'tunai' ? numericCash : grandTotal,
      changeAmount: paymentMethod === 'tunai' ? changeAmount : 0,
      customerName: customerName.trim() || undefined
    };

    onCompleteTransaction(newTx);

    // Reset local view state
    setCart([]);
    setCashGiven('');
    setDiscountAmount(0);
    setCustomerName('');
    setPaymentError(null);
  };

  const formatRupiah = (val: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0
    }).format(val);
  };

  const isEffectiveLandscape = isLandscape || (typeof window !== 'undefined' ? (window.innerWidth > window.innerHeight || window.innerWidth >= 768) : true);

  return (
    <div className="space-y-4">
      {/* Visual Indicator of 2-Column Mode */}
      <div className={`${isEffectiveLandscape ? 'flex' : 'hidden landscape:flex md:flex'} items-center justify-between px-4 py-2 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800`}>
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
          <span className="font-bold">Mode 2 Kolom Aktif</span>
          <span className="text-slate-600 font-medium">• Kolom Kiri: Transaksi | Kolom Kanan: Pembayaran</span>
        </div>
        <div className="font-mono text-emerald-700 font-medium text-[11px] sm:text-xs">
          {cart.length} Jenis Produk Dipilih
        </div>
      </div>

      {/* Grid: 2 Columns on Landscape / Large screen */}
      <div className={`grid gap-5 items-start kasir-landscape-grid ${
        isEffectiveLandscape
          ? 'grid-cols-12'
          : 'grid-cols-1 landscape:grid-cols-12 md:grid-cols-12'
      }`}>
        
        {/* ========================================================= */}
        {/* SEBELAH KIRI: KOLOM TRANSAKSI (KERANJANG & KATALOG)       */}
        {/* ========================================================= */}
        <section 
          id="kolom-kiri-transaksi" 
          className={`${
            isEffectiveLandscape
              ? 'col-span-7'
              : 'col-span-1 landscape:col-span-7 md:col-span-7'
          } kasir-col-kiri-transaksi space-y-4`}
        >
          {/* Box 1: Keranjang Aktif */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="px-4 py-3 bg-slate-50/80 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-emerald-100 text-emerald-700 rounded-lg">
                  <ShoppingCart className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-md bg-emerald-100 text-emerald-800 uppercase tracking-wider">
                      Kolom Kiri
                    </span>
                    <h2 className="font-bold text-slate-800 text-sm">Transaksi Kasir</h2>
                  </div>
                  <p className="text-[11px] text-slate-500">
                    {cart.reduce((sum, item) => sum + item.quantity, 0)} total item di keranjang belanja
                  </p>
                </div>
              </div>

              {cart.length > 0 && (
                <button
                  type="button"
                  onClick={handleClearCart}
                  className="inline-flex items-center gap-1 text-xs text-rose-600 hover:text-rose-700 hover:bg-rose-50 px-2.5 py-1 rounded-lg transition-colors font-medium"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Kosongkan</span>
                </button>
              )}
            </div>

            {/* Cart Items List */}
            <div className="divide-y divide-slate-100 max-h-[320px] overflow-y-auto">
              {cart.length === 0 ? (
                <div className="p-8 text-center space-y-2">
                  <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 mx-auto flex items-center justify-center">
                    <ShoppingBag className="w-6 h-6" />
                  </div>
                  <h4 className="font-semibold text-sm text-slate-700">Keranjang Belanja Kosong</h4>
                  <p className="text-xs text-slate-500 max-w-xs mx-auto">
                    Klik salah satu produk pada katalog di bawah untuk menambahkan barang ke keranjang.
                  </p>
                </div>
              ) : (
                cart.map((item) => (
                  <div 
                    key={item.product.id}
                    className="p-3 sm:px-4 flex items-center justify-between gap-3 hover:bg-slate-50/50 transition-colors"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="font-semibold text-xs sm:text-sm text-slate-800 truncate">
                        {item.product.name}
                      </div>
                      <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-0.5">
                        <span className="font-mono text-emerald-600 font-medium">
                          {formatRupiah(item.product.sellingPrice)}
                        </span>
                        <span>•</span>
                        <span>Sisa stok: {item.product.stock}</span>
                      </div>
                    </div>

                    {/* Quantity Controls */}
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleUpdateQty(item.product.id, -1)}
                        className="w-7 h-7 rounded-lg border border-slate-300 hover:bg-slate-100 flex items-center justify-center text-slate-700 transition-colors active:scale-95"
                        title="Kurangi kuantitas"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="w-8 text-center font-bold text-xs text-slate-800">
                        {item.quantity}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleUpdateQty(item.product.id, 1)}
                        disabled={item.quantity >= item.product.stock}
                        className="w-7 h-7 rounded-lg border border-slate-300 hover:bg-slate-100 flex items-center justify-center text-slate-700 transition-colors disabled:opacity-40 active:scale-95"
                        title="Tambah kuantitas"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Item Subtotal & Delete */}
                    <div className="text-right shrink-0 min-w-[75px]">
                      <div className="font-bold text-xs sm:text-sm text-slate-900">
                        {formatRupiah(item.product.sellingPrice * item.quantity)}
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRemoveItem(item.product.id)}
                        className="text-[11px] text-rose-500 hover:text-rose-700 inline-flex items-center gap-0.5 mt-0.5"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>Hapus</span>
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Cart Mini Footer */}
            {cart.length > 0 && (
              <div className="px-4 py-2.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs">
                <span className="text-slate-600 font-medium">Subtotal Belanja:</span>
                <span className="font-bold text-sm text-emerald-700">{formatRupiah(subtotal)}</span>
              </div>
            )}
          </div>

          {/* Box 2: Pemilih Barang Cepat (Katalog Rak Belanja) */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-4 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <h3 className="font-bold text-sm text-slate-800 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>Pilih Barang untuk Keranjang</span>
              </h3>

              {/* Search Bar */}
              <div className="relative w-full sm:w-60">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Cari nama / barcode..."
                  className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                />
              </div>
            </div>

            {/* Category Filter Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
              {CATEGORIES.slice(0, 6).map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-2.5 py-1 rounded-lg whitespace-nowrap transition-colors font-medium text-xs ${
                    selectedCategory === cat
                      ? 'bg-emerald-600 text-white shadow-2xs'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Product Cards Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-[360px] overflow-y-auto pr-1">
              {filteredProducts.map((prod) => {
                const inCart = cart.find((c) => c.product.id === prod.id);
                const isOutOfStock = prod.stock <= 0;

                return (
                  <button
                    key={prod.id}
                    type="button"
                    onClick={() => handleAddToCart(prod)}
                    disabled={isOutOfStock}
                    className={`p-2.5 rounded-xl border text-left flex flex-col justify-between transition-all duration-150 active:scale-98 ${
                      isOutOfStock 
                        ? 'bg-slate-50 border-slate-200 opacity-60 cursor-not-allowed'
                        : inCart
                        ? 'bg-emerald-50/60 border-emerald-300 ring-1 ring-emerald-400/50 hover:bg-emerald-50 shadow-2xs'
                        : 'bg-white border-slate-200 hover:border-emerald-300 hover:shadow-xs'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <span className="text-[10px] font-medium px-1.5 py-0.2 rounded-md bg-slate-100 text-slate-600 truncate max-w-[80px]">
                          {prod.category}
                        </span>
                        <span className={`text-[10px] font-bold ${
                          prod.stock <= 0 
                            ? 'text-rose-600' 
                            : prod.stock <= 5 
                            ? 'text-amber-600' 
                            : 'text-slate-500'
                        }`}>
                          {prod.stock <= 0 ? 'Habis' : `Stok: ${prod.stock}`}
                        </span>
                      </div>
                      <div className="font-semibold text-xs text-slate-800 line-clamp-2 leading-tight">
                        {prod.name}
                      </div>
                    </div>

                    <div className="mt-2 flex items-center justify-between pt-1 border-t border-slate-100">
                      <span className="font-bold text-xs text-emerald-700">
                        {formatRupiah(prod.sellingPrice)}
                      </span>
                      {inCart ? (
                        <span className="w-5 h-5 rounded-md bg-emerald-600 text-white flex items-center justify-center text-[11px] font-bold">
                          {inCart.quantity}
                        </span>
                      ) : (
                        <div className="w-5 h-5 rounded-md bg-slate-100 hover:bg-emerald-600 hover:text-white text-slate-500 flex items-center justify-center transition-colors">
                          <Plus className="w-3 h-3" />
                        </div>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </section>


        {/* ========================================================= */}
        {/* SEBELAH KANAN: KOLOM PEMBAYARAN (CHECKOUT & CASHIER)     */}
        {/* ========================================================= */}
        <section 
          id="kolom-kanan-pembayaran" 
          className={`${
            isEffectiveLandscape
              ? 'col-span-5 sticky top-20'
              : 'col-span-1 landscape:col-span-5 md:col-span-5 landscape:sticky landscape:top-20 md:sticky md:top-20'
          } kasir-col-kanan-pembayaran space-y-4`}
        >
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 space-y-4">
            {/* Header Kolom Pembayaran */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-indigo-100 text-indigo-700 rounded-lg">
                  <CreditCard className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-md bg-indigo-100 text-indigo-800 uppercase tracking-wider">
                      Kolom Kanan
                    </span>
                    <h2 className="font-bold text-slate-800 text-sm">Pembayaran</h2>
                  </div>
                  <p className="text-[11px] text-slate-500">Proses transaksi &amp; cetak struk</p>
                </div>
              </div>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 font-medium">
                {cart.length} Produk
              </span>
            </div>

            {/* Ringkasan Total Tagihan Utama */}
            <div className="p-4 bg-gradient-to-br from-slate-900 to-slate-800 rounded-xl text-white shadow-sm space-y-1">
              <span className="text-xs text-slate-400 font-medium">TOTAL TAGIHAN</span>
              <div className="text-2xl sm:text-3xl font-black tracking-tight text-emerald-400">
                {formatRupiah(grandTotal)}
              </div>
              <div className="flex justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-700/50">
                <span>Subtotal: {formatRupiah(subtotal)}</span>
                {discountAmount > 0 && <span className="text-amber-400">Hemat: {formatRupiah(discountAmount)}</span>}
              </div>
            </div>

            {/* Diskon & Pelanggan Opsional */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <label className="block text-[11px] text-slate-600 font-medium mb-1">
                  Nama Pembeli (Opsional)
                </label>
                <div className="relative">
                  <User className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="Pelanggan umum"
                    className="w-full pl-7 pr-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] text-slate-600 font-medium mb-1">
                  Potongan Diskon (Rp)
                </label>
                <div className="relative">
                  <Percent className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="number"
                    value={discountAmount || ''}
                    onChange={(e) => setDiscountAmount(Math.max(0, Number(e.target.value)))}
                    placeholder="0"
                    min="0"
                    className="w-full pl-7 pr-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500 focus:bg-white"
                  />
                </div>
              </div>
            </div>

            {/* Metode Pembayaran Tabs */}
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-700">
                Metode Pembayaran
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => { setPaymentMethod('tunai'); setPaymentError(null); }}
                  className={`p-2 rounded-xl border flex flex-col items-center gap-1 text-center transition-all ${
                    paymentMethod === 'tunai'
                      ? 'bg-emerald-50 border-emerald-500 text-emerald-700 font-bold ring-1 ring-emerald-500 shadow-2xs'
                      : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <Banknote className="w-4 h-4" />
                  <span className="text-xs">Tunai (Cash)</span>
                </button>

                <button
                  type="button"
                  onClick={() => { setPaymentMethod('qris'); setPaymentError(null); }}
                  className={`p-2 rounded-xl border flex flex-col items-center gap-1 text-center transition-all ${
                    paymentMethod === 'qris'
                      ? 'bg-emerald-50 border-emerald-500 text-emerald-700 font-bold ring-1 ring-emerald-500 shadow-2xs'
                      : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <QrCode className="w-4 h-4" />
                  <span className="text-xs">QRIS Instan</span>
                </button>

                <button
                  type="button"
                  onClick={() => { setPaymentMethod('debit'); setPaymentError(null); }}
                  className={`p-2 rounded-xl border flex flex-col items-center gap-1 text-center transition-all ${
                    paymentMethod === 'debit'
                      ? 'bg-emerald-50 border-emerald-500 text-emerald-700 font-bold ring-1 ring-emerald-500 shadow-2xs'
                      : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <CreditCard className="w-4 h-4" />
                  <span className="text-xs">Debit / TF</span>
                </button>
              </div>
            </div>

            {/* Input Tunai & Pecahan Uang Cepat (Jika Tunai) */}
            {paymentMethod === 'tunai' ? (
              <div className="space-y-2.5 p-3 bg-slate-50 rounded-xl border border-slate-200">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-700">
                    Uang Diterima (Tunai)
                  </label>
                  <button
                    type="button"
                    onClick={() => setPresetCash(grandTotal)}
                    className="text-[11px] font-bold text-indigo-600 hover:text-indigo-700 hover:underline"
                  >
                    Uang Pas ({formatRupiah(grandTotal)})
                  </button>
                </div>

                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 font-bold text-xs text-slate-500">
                    Rp
                  </span>
                  <input
                    type="number"
                    value={cashGiven}
                    onChange={(e) => {
                      setCashGiven(e.target.value);
                      setPaymentError(null);
                    }}
                    placeholder="Ketik nominal uang diterima..."
                    className="w-full pl-9 pr-3 py-2 text-sm font-bold bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  />
                </div>

                {/* Tombol Pecahan Uang Cepat */}
                <div className="grid grid-cols-4 gap-1.5 pt-1">
                  {[10000, 20000, 50000, 100000].map((nominal) => (
                    <button
                      key={nominal}
                      type="button"
                      onClick={() => setPresetCash(nominal)}
                      className="px-1.5 py-1.5 rounded-lg bg-white hover:bg-slate-200 border border-slate-200 text-[11px] font-semibold text-slate-700 transition-colors text-center"
                    >
                      {nominal >= 1000 ? `${nominal / 1000}rb` : nominal}
                    </button>
                  ))}
                </div>

                {/* Kembalian Realtime */}
                <div className="pt-2 border-t border-slate-200/80 flex items-center justify-between">
                  <span className="text-xs font-medium text-slate-600">Kembalian:</span>
                  <span className={`text-base font-black ${
                    numericCash >= grandTotal 
                      ? 'text-emerald-700' 
                      : 'text-rose-600'
                  }`}>
                    {numericCash >= grandTotal 
                      ? formatRupiah(changeAmount) 
                      : numericCash > 0 
                      ? `Kurang ${formatRupiah(grandTotal - numericCash)}` 
                      : 'Rp 0'}
                  </span>
                </div>
              </div>
            ) : (
              <div className="p-3 bg-emerald-50/70 rounded-xl border border-emerald-200 text-xs text-emerald-800 space-y-1">
                <div className="flex items-center gap-1.5 font-bold">
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span>Pembayaran {paymentMethod.toUpperCase()} Terpilih</span>
                </div>
                <p className="text-[11px] text-emerald-700">
                  Tagihan sebesar {formatRupiah(grandTotal)} akan otomatis lunas saat Anda menekan tombol Selesaikan Transaksi di bawah.
                </p>
              </div>
            )}

            {/* Error message */}
            {paymentError && (
              <div className="p-2.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{paymentError}</span>
              </div>
            )}

            {/* Tombol Utama Pembayaran */}
            <button
              type="button"
              onClick={handleProcessPayment}
              disabled={cart.length === 0 || (paymentMethod === 'tunai' && numericCash < grandTotal)}
              className="w-full py-3.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm flex items-center justify-center gap-2 transition-all shadow-md active:scale-98 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
            >
              <ReceiptText className="w-5 h-5" />
              <span>Bayar &amp; Selesai ({formatRupiah(grandTotal)})</span>
            </button>
          </div>
        </section>

      </div>
    </div>
  );
};
