import React, { useState } from 'react';
import { PIPELINE_STEPS } from '../data/workflowContent';
import { CheckCircle2, ChevronRight, Terminal, Layers } from 'lucide-react';

export const PipelineStepList: React.FC = () => {
  const [filter, setFilter] = useState<'all' | 'setup' | 'build' | 'android' | 'deploy'>('all');

  const filteredSteps = filter === 'all' 
    ? PIPELINE_STEPS 
    : PIPELINE_STEPS.filter(s => s.category === filter);

  return (
    <div id="pipeline-steps-container" className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-5 border-b border-slate-100 gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Layers className="w-5 h-5 text-indigo-600" />
            Tahapan Pipeline Eksekusi (14 Langkah)
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Urutan proses yang dijalankan oleh GitHub Actions runner untuk menghasilkan file APK.
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap gap-1 bg-slate-100 p-1 rounded-xl">
          {(['all', 'setup', 'build', 'android', 'deploy'] as const).map(cat => (
            <button
              key={cat}
              type="button"
              onClick={() => setFilter(cat)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all capitalize ${
                filter === cat
                  ? 'bg-white text-slate-900 shadow-2xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {cat === 'all' ? 'Semua' : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Steps List */}
      <div className="mt-5 space-y-3">
        {filteredSteps.map((step) => {
          const isAndroid = step.category === 'android';
          const isBuild = step.category === 'build';
          const isDeploy = step.category === 'deploy';

          const badgeColor = isAndroid
            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
            : isBuild
            ? 'bg-blue-50 text-blue-700 border-blue-200'
            : isDeploy
            ? 'bg-purple-50 text-purple-700 border-purple-200'
            : 'bg-amber-50 text-amber-700 border-amber-200';

          return (
            <div
              key={step.id}
              className="group p-4 rounded-xl border border-slate-100 hover:border-slate-300 hover:bg-slate-50/50 transition-all flex flex-col md:flex-row md:items-center justify-between gap-3"
            >
              <div className="flex items-start gap-3.5">
                <div className="flex-shrink-0 w-8 h-8 rounded-lg bg-indigo-50 border border-indigo-100 text-indigo-700 font-bold text-xs flex items-center justify-center">
                  {step.number}
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-sm font-bold text-slate-800">{step.title}</h3>
                    <span className={`text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full border ${badgeColor}`}>
                      {step.category}
                    </span>
                    {step.status === 'mandatory' && (
                      <span className="text-[10px] text-slate-500 flex items-center gap-0.5">
                        <CheckCircle2 className="w-3 h-3 text-emerald-500" /> Wajib
                      </span>
                    )}
                    {step.status === 'conditional' && (
                      <span className="text-[10px] text-amber-600 font-medium px-1.5 py-0.5 bg-amber-50 rounded">
                        Kondisional
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                    {step.description}
                  </p>
                </div>
              </div>

              {/* Action / Command tag */}
              <div className="flex items-center gap-2 bg-slate-900 text-slate-200 px-3 py-1.5 rounded-lg text-xs font-mono max-w-full overflow-x-auto">
                <Terminal className="w-3.5 h-3.5 text-indigo-400 flex-shrink-0" />
                <span className="truncate">{step.commandOrAction}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
