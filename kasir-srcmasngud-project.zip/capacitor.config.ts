import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.srcmasngud.kasir',
  appName: 'Kasir',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
