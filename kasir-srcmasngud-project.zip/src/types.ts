export interface PipelineStep {
  id: string;
  number: number;
  title: string;
  description: string;
  commandOrAction: string;
  category: 'setup' | 'build' | 'deploy' | 'android';
  status: 'mandatory' | 'conditional' | 'optional';
}

export interface WorkflowMetadata {
  name: string;
  filename: string;
  path: string;
  appId: string;
  appName: string;
  jdkVersion: string;
  nodeVersion: string;
  androidTarget: string;
  outputArtifactName: string;
}

export interface Product {
  id: string;
  name: string;
  barcode: string;
  category: string;
  costPrice: number;
  sellingPrice: number;
  stock: number;
  unit: string;
  minStockAlert?: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
  discount: number; // Diskon nominal per item
}

export interface Transaction {
  id: string;
  invoiceNumber: string;
  date: string;
  items: CartItem[];
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  paymentMethod: 'tunai' | 'qris' | 'debit' | 'transfer';
  cashAmount: number;
  changeAmount: number;
  customerName?: string;
  notes?: string;
}
