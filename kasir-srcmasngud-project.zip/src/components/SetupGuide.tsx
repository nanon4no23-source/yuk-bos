import React, { useState } from 'react';
import { HelpCircle, Play, Download, ShieldCheck, FolderGit2, Smartphone, Terminal, ExternalLink } from 'lucide-react';
import { WORKFLOW_METADATA } from '../data/workflowContent';

export const SetupGuide: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'quickstart' | 'dispatch' | 'secrets' | 'capacitor'>('quickstart');

  return (
    <div id="setup-guide-container" className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-2">
        <div className="flex items-center gap-2">
          <HelpCircle className="w-5 h-5 text-indigo-600" />
          <h2 className="text-lg font-bold text-slate-900">Petunjuk Penggunaan Workflow di GitHub</h2>
        </div>

        {/* Sub-tabs */}
        <div className="flex flex-wrap gap-1 bg-slate-100 p-1 rounded-xl">
          <button
            type="button"
            onClick={() => setActiveTab('quickstart')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              activeTab === 'quickstart' ? 'bg-white text-indigo-700 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Cara Pasang
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('dispatch')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              activeTab === 'dispatch' ? 'bg-white text-indigo-700 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Trigger Manual & Unduh
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('secrets')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              activeTab === 'secrets' ? 'bg-white text-indigo-700 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Keystore / Rilis
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('capacitor')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              activeTab === 'capacitor' ? 'bg-white text-indigo-700 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Info Proyek Kasir
          </button>
        </div>
      </div>

      {/* Tab 1: Cara Pasang */}
      {activeTab === 'quickstart' && (
        <div className="mt-5 space-y-4 text-xs text-slate-600 leading-relaxed">
          <div className="p-4 rounded-xl bg-indigo-50/70 border border-indigo-100 flex items-start gap-3">
            <FolderGit2 className="w-5 h-5 text-indigo-600 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-bold text-indigo-900 text-sm">Lokasi Penyimpanan File di Repository</h4>
              <p className="mt-1 text-indigo-700">
                Agar GitHub Actions otomatis mengenali workflow ini, pastikan file disimpan pada direktori:
              </p>
              <div className="mt-2 bg-slate-900 text-slate-100 font-mono text-xs px-3 py-2 rounded-lg inline-block">
                .github/workflows/build-apk.yml
              </div>
            </div>
          </div>

          <ol className="space-y-3 pl-2">
            <li className="flex items-start gap-2">
              <span className="flex-shrink-0 w-5 h-5 rounded-full bg-slate-100 font-bold text-slate-700 flex items-center justify-center text-[11px]">1</span>
              <div>
                <strong>Buat folder .github/workflows:</strong> Di komputer lokal atau langsung di web GitHub, buat folder bernama <code className="bg-slate-100 px-1 py-0.5 rounded text-slate-800">.github/workflows/</code>.
              </div>
            </li>
            <li className="flex items-start gap-2">
              <span className="flex-shrink-0 w-5 h-5 rounded-full bg-slate-100 font-bold text-slate-700 flex items-center justify-center text-[11px]">2</span>
              <div>
                <strong>Simpan file build-apk.yml:</strong> Masukkan file <code className="bg-slate-100 px-1 py-0.5 rounded text-slate-800">build-apk.yml</code> yang sudah dibuat ke dalam folder tersebut.
              </div>
            </li>
            <li className="flex items-start gap-2">
              <span className="flex-shrink-0 w-5 h-5 rounded-full bg-slate-100 font-bold text-slate-700 flex items-center justify-center text-[11px]">3</span>
              <div>
                <strong>Commit & Push ke GitHub:</strong> Lakukan commit dan push ke branch <code className="bg-slate-100 px-1 py-0.5 rounded text-slate-800">main</code> atau <code className="bg-slate-100 px-1 py-0.5 rounded text-slate-800">master</code>:
                <pre className="mt-1.5 p-2.5 bg-slate-900 text-slate-200 rounded-lg font-mono text-[11px]">
                  git add .github/workflows/build-apk.yml{'\n'}
                  git commit -m "Add GitHub Actions workflow for building Android APK"{'\n'}
                  git push origin main
                </pre>
              </div>
            </li>
          </ol>
        </div>
      )}

      {/* Tab 2: Trigger Manual & Unduh */}
      {activeTab === 'dispatch' && (
        <div className="mt-5 space-y-4 text-xs text-slate-600 leading-relaxed">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50">
              <div className="flex items-center gap-2 font-bold text-slate-900 mb-2">
                <Play className="w-4 h-4 text-emerald-600" />
                Cara Menjalankan Build Manual (Workflow Dispatch)
              </div>
              <ol className="space-y-1.5 pl-4 list-decimal text-slate-600">
                <li>Buka repositori GitHub Anda di browser.</li>
                <li>Klik tab <strong>Actions</strong> di menu atas.</li>
                <li>Pilih workflow <strong>Build Android APK (Capacitor)</strong> di sidebar kiri.</li>
                <li>Klik tombol <strong>Run workflow</strong> di sebelah kanan.</li>
                <li>Pilih branch dan tipe APK (<code className="text-indigo-600">debug</code>, <code className="text-indigo-600">release</code>, atau <code className="text-indigo-600">both</code>).</li>
                <li>Klik tombol hijau <strong>Run workflow</strong> untuk memulai build.</li>
              </ol>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50">
              <div className="flex items-center gap-2 font-bold text-slate-900 mb-2">
                <Download className="w-4 h-4 text-indigo-600" />
                Cara Mengunduh Hasil APK
              </div>
              <ol className="space-y-1.5 pl-4 list-decimal text-slate-600">
                <li>Klik proses run yang sedang atau telah selesai berjalan di tab Actions.</li>
                <li>Gulir ke bawah ke bagian <strong>Artifacts</strong> pada halaman Summary.</li>
                <li>Anda akan melihat file artifact bernama <strong>android-apk-...</strong>.</li>
                <li>Klik artifact tersebut untuk mengunduh zip yang berisi file APK (<code className="text-emerald-700">app-debug.apk</code>).</li>
                <li>Ekstrak dan instal file APK langsung ke HP Android Anda!</li>
              </ol>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Secrets & Signing */}
      {activeTab === 'secrets' && (
        <div className="mt-5 space-y-3 text-xs text-slate-600 leading-relaxed">
          <div className="p-4 rounded-xl bg-amber-50/80 border border-amber-200/80">
            <div className="flex items-center gap-2 font-bold text-amber-900 mb-1">
              <ShieldCheck className="w-4 h-4 text-amber-700" />
              Untuk Rilis Resmi / Google Play Store (Opsional)
            </div>
            <p className="text-amber-800">
              APK Debug dapat langsung dipasang tanpa keystore. Namun jika Anda ingin mem-build APK Release yang ditandatangani secara otomatis, daftarkan 4 secret ini di <strong>Settings &gt; Secrets and variables &gt; Actions</strong> di repositori GitHub Anda:
            </p>
          </div>

          <div className="space-y-2">
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <code className="text-indigo-600 font-bold">ANDROID_KEYSTORE_BASE64</code>
              <p className="text-slate-500 text-[11px] mt-0.5">File release.keystore yang di-encode ke format base64 (<code className="text-slate-700">base64 -w 0 my-release-key.keystore</code>).</p>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <code className="text-indigo-600 font-bold">KEYSTORE_PASSWORD</code>
              <p className="text-slate-500 text-[11px] mt-0.5">Password utama dari keystore Anda.</p>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <code className="text-indigo-600 font-bold">KEY_ALIAS</code>
              <p className="text-slate-500 text-[11px] mt-0.5">Nama alias key saat membuat keystore (contoh: <code className="text-slate-700">kasir-key</code>).</p>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <code className="text-indigo-600 font-bold">KEY_PASSWORD</code>
              <p className="text-slate-500 text-[11px] mt-0.5">Password khusus untuk key alias tersebut.</p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Info Proyek Kasir */}
      {activeTab === 'capacitor' && (
        <div className="mt-5 space-y-3 text-xs text-slate-600 leading-relaxed">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Nama Aplikasi</span>
              <p className="text-slate-900 font-bold text-sm mt-0.5">{WORKFLOW_METADATA.appName}</p>
            </div>
            <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Application Package ID</span>
              <p className="text-slate-900 font-mono text-sm mt-0.5">{WORKFLOW_METADATA.appId}</p>
            </div>
            <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Environment Build</span>
              <p className="text-slate-900 font-medium text-sm mt-0.5">{WORKFLOW_METADATA.jdkVersion} &amp; {WORKFLOW_METADATA.nodeVersion}</p>
            </div>
            <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Lokasi Output APK</span>
              <p className="text-slate-900 font-mono text-xs mt-0.5">android/app/build/outputs/apk/debug/</p>
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-slate-600">
            <div className="flex items-center gap-1.5 font-semibold text-slate-800 mb-1">
              <Smartphone className="w-4 h-4 text-emerald-600" />
              Kompatibilitas Capacitor Android
            </div>
            <p className="text-[11px]">
              Workflow ini sudah disesuaikan dengan berkas zip yang diunggah yang berisi proyek Android Capacitor <code className="text-indigo-600 font-semibold">{WORKFLOW_METADATA.appId}</code> dengan fitur Bluetooth Thermal Printer dan File Manager.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
