import React from 'react';
import { Printer, CheckCircle2, X, Share2, ShoppingBag } from 'lucide-react';
import { Transaction } from '../types';

interface StrukModalProps {
  transaction: Transaction | null;
  onClose: () => void;
  onNewTransaction: () => void;
}

export const StrukModal: React.FC<StrukModalProps> = ({
  transaction,
  onClose,
  onNewTransaction
}) => {
  if (!transaction) return null;

  const handlePrint = () => {
    window.print();
  };

  const formatRupiah = (val: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0
    }).format(val);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl overflow-hidden my-auto flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="bg-emerald-600 px-6 py-4 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 bg-emerald-500 rounded-lg">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base">Pembayaran Berhasil!</h3>
              <p className="text-xs text-emerald-100">{transaction.invoiceNumber}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-emerald-700 rounded-lg transition-colors text-emerald-100 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Printable Receipt Paper */}
        <div className="p-6 overflow-y-auto flex-1 bg-slate-50 flex justify-center">
          <div 
            id="thermal-receipt" 
            className="w-full max-w-[340px] bg-white border border-dashed border-slate-300 p-5 rounded-lg font-mono text-xs text-slate-800 shadow-xs"
          >
            {/* Header Toko */}
            <div className="text-center pb-3 border-b border-dashed border-slate-300">
              <div className="flex items-center justify-center gap-1.5 font-sans font-black text-base text-slate-900">
                <ShoppingBag className="w-4 h-4 text-emerald-600" />
                <span>KASIR SRC MASNGUD</span>
              </div>
              <p className="text-[11px] text-slate-600 mt-0.5">Toko Kelontong & Sembako Murah</p>
              <p className="text-[10px] text-slate-500">Jl. Raya Utama No. 23 - Telp: 0812-3456-7890</p>
            </div>

            {/* Meta Transaksi */}
            <div className="py-2.5 border-b border-dashed border-slate-300 space-y-1 text-[11px] text-slate-600">
              <div className="flex justify-between">
                <span>No. Transaksi</span>
                <span className="font-bold text-slate-800">{transaction.invoiceNumber}</span>
              </div>
              <div className="flex justify-between">
                <span>Waktu</span>
                <span>{transaction.date}</span>
              </div>
              <div className="flex justify-between">
                <span>Kasir</span>
                <span>Mas Ngud</span>
              </div>
              {transaction.customerName && (
                <div className="flex justify-between">
                  <span>Pelanggan</span>
                  <span className="font-semibold text-slate-800">{transaction.customerName}</span>
                </div>
              )}
            </div>

            {/* List Barang */}
            <div className="py-2.5 border-b border-dashed border-slate-300 space-y-2">
              {transaction.items.map((item, idx) => (
                <div key={idx} className="space-y-0.5">
                  <div className="font-semibold text-slate-900 truncate">
                    {item.product.name}
                  </div>
                  <div className="flex justify-between text-slate-600 text-[11px]">
                    <span>
                      {item.quantity} {item.product.unit || 'pcs'} x {formatRupiah(item.product.sellingPrice)}
                    </span>
                    <span className="font-medium text-slate-900">
                      {formatRupiah(item.quantity * item.product.sellingPrice)}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Ringkasan Biaya */}
            <div className="py-2.5 border-b border-dashed border-slate-300 space-y-1 text-[11px]">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal ({transaction.items.reduce((acc, i) => acc + i.quantity, 0)} item)</span>
                <span>{formatRupiah(transaction.subtotal)}</span>
              </div>
              {transaction.discount > 0 && (
                <div className="flex justify-between text-rose-600">
                  <span>Diskon</span>
                  <span>-{formatRupiah(transaction.discount)}</span>
                </div>
              )}
              {transaction.tax > 0 && (
                <div className="flex justify-between text-slate-600">
                  <span>Pajak (PPN)</span>
                  <span>+{formatRupiah(transaction.tax)}</span>
                </div>
              )}
              <div className="flex justify-between text-sm font-bold text-slate-900 pt-1 border-t border-slate-200">
                <span>TOTAL AKHIR</span>
                <span className="text-emerald-700">{formatRupiah(transaction.total)}</span>
              </div>
            </div>

            {/* Info Pembayaran */}
            <div className="py-2.5 border-b border-dashed border-slate-300 space-y-1 text-[11px]">
              <div className="flex justify-between text-slate-600">
                <span>Metode Bayar</span>
                <span className="font-bold uppercase text-slate-800">{transaction.paymentMethod}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Bayar Diterima</span>
                <span className="font-medium text-slate-900">{formatRupiah(transaction.cashAmount)}</span>
              </div>
              <div className="flex justify-between text-slate-900 font-bold">
                <span>Kembalian</span>
                <span className="text-emerald-700">{formatRupiah(transaction.changeAmount)}</span>
              </div>
            </div>

            {/* Footer Ucapan */}
            <div className="text-center pt-3 text-[10px] text-slate-500 space-y-0.5">
              <p className="font-medium text-slate-700">Terima Kasih Atas Kunjungan Anda!</p>
              <p>Barang yang sudah dibeli tidak dapat ditukar</p>
              <p className="pt-1">*** Layanan POS SRC Masngud ***</p>
            </div>
          </div>
        </div>

        {/* Modal Action Buttons */}
        <div className="p-4 bg-white border-t border-slate-200 flex items-center justify-between gap-3 shrink-0">
          <button
            type="button"
            onClick={onNewTransaction}
            className="flex-1 px-4 py-2.5 rounded-xl border border-slate-300 hover:bg-slate-100 font-semibold text-xs text-slate-700 transition-colors text-center"
          >
            Transaksi Baru
          </button>
          <button
            type="button"
            onClick={handlePrint}
            className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs transition-colors shadow-xs"
          >
            <Printer className="w-4 h-4" />
            <span>Cetak Struk</span>
          </button>
        </div>
      </div>
    </div>
  );
};
