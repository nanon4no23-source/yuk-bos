import React, { useState } from 'react';
import { 
  Receipt, 
  Calendar, 
  Search, 
  Printer, 
  Trash2, 
  TrendingUp, 
  ShoppingBag,
  Clock,
  User,
  ArrowUpRight,
  HardDrive,
  ChevronDown
} from 'lucide-react';
import { Transaction } from '../types';

interface RiwayatViewProps {
  transactions: Transaction[];
  onSelectReceipt: (transaction: Transaction) => void;
  onClearHistory: () => void;
  onOpenStorageManager?: () => void;
}

export const RiwayatView: React.FC<RiwayatViewProps> = ({
  transactions,
  onSelectReceipt,
  onClearHistory,
  onOpenStorageManager
}) => {
  const [search, setSearch] = useState('');
  const [visibleCount, setVisibleCount] = useState<number>(25);

  const filtered = transactions.filter((tx) => {
    const q = search.toLowerCase();
    return (
      tx.invoiceNumber.toLowerCase().includes(q) ||
      (tx.customerName && tx.customerName.toLowerCase().includes(q)) ||
      tx.items.some((i) => i.product.name.toLowerCase().includes(q))
    );
  });

  const totalOmset = transactions.reduce((acc, tx) => acc + tx.total, 0);
  const totalItemsSold = transactions.reduce(
    (acc, tx) => acc + tx.items.reduce((s, i) => s + i.quantity, 0),
    0
  );

  const visibleTransactions = filtered.slice(0, visibleCount);

  const formatRupiah = (val: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0
    }).format(val);
  };

  return (
    <div className="space-y-4">
      {/* Summary metric cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span>Total Omset Penjualan</span>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-xl font-black text-emerald-700 mt-1">
            {formatRupiah(totalOmset)}
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">Dari seluruh transaksi tercatat</p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span>Jumlah Transaksi</span>
            <Receipt className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-xl font-black text-indigo-700 mt-1">
            {transactions.length} Transaksi
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">Berhasil diselesaikan</p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span>Total Produk Terjual</span>
            <ShoppingBag className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-xl font-black text-amber-700 mt-1">
            {totalItemsSold} Unit
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">Produk keluar dari stok</p>
        </div>
      </div>

      {/* Main Table Container */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 bg-slate-50/80 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="font-bold text-sm text-slate-800">Daftar Riwayat Penjualan</h3>
            <p className="text-xs text-slate-500">Klik cetak struk untuk mencetak ulang tanda bukti</p>
          </div>

          <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Cari faktur / pelanggan..."
                className="pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
              />
            </div>

            {onOpenStorageManager && (
              <button
                type="button"
                onClick={onOpenStorageManager}
                className="text-xs text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 px-2.5 py-1.5 rounded-lg font-semibold transition-colors inline-flex items-center gap-1 shrink-0"
                title="Buka pengaturan kapasitas penyimpanan & backup"
              >
                <HardDrive className="w-3.5 h-3.5 text-indigo-600" />
                <span>Kelola Memori</span>
              </button>
            )}

            {transactions.length > 0 && (
              <button
                type="button"
                onClick={onClearHistory}
                className="text-xs text-rose-600 hover:text-rose-700 hover:bg-rose-50 px-2.5 py-1.5 rounded-lg font-medium transition-colors inline-flex items-center gap-1 shrink-0"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Hapus</span>
              </button>
            )}
          </div>
        </div>

        <div className="divide-y divide-slate-100 max-h-[480px] overflow-y-auto">
          {filtered.length === 0 ? (
            <div className="p-10 text-center space-y-2">
              <Receipt className="w-10 h-10 text-slate-300 mx-auto" />
              <p className="font-semibold text-sm text-slate-700">Belum ada riwayat transaksi</p>
              <p className="text-xs text-slate-500">
                Selesaikan transaksi di menu Kasir untuk melihat riwayat penjualan di sini.
              </p>
            </div>
          ) : (
            <>
              {visibleTransactions.map((tx) => (
                <div 
                  key={tx.id}
                  className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/70 transition-colors"
                >
                  <div className="space-y-1 min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-xs sm:text-sm text-slate-900">
                        {tx.invoiceNumber}
                      </span>
                      <span className="text-[10px] font-bold px-2 py-0.2 rounded-full uppercase bg-emerald-100 text-emerald-800">
                        {tx.paymentMethod}
                      </span>
                      {tx.customerName && (
                        <span className="text-[11px] text-slate-500 flex items-center gap-1">
                          <User className="w-3 h-3" />
                          <span>{tx.customerName}</span>
                        </span>
                      )}
                    </div>

                    <div className="text-xs text-slate-600 truncate">
                      {tx.items.map((i) => `${i.product.name} (${i.quantity})`).join(', ')}
                    </div>

                    <div className="text-[11px] text-slate-400 flex items-center gap-1 font-mono">
                      <Clock className="w-3 h-3" />
                      <span>{tx.date}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 shrink-0 self-end sm:self-center">
                    <div className="text-right">
                      <div className="font-bold text-sm text-slate-900">
                        {formatRupiah(tx.total)}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        {tx.items.reduce((s, i) => s + i.quantity, 0)} item
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => onSelectReceipt(tx)}
                      className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-emerald-600 hover:text-white text-slate-700 text-xs font-semibold transition-colors"
                      title="Buka struk transaksi"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>Lihat Struk</span>
                    </button>
                  </div>
                </div>
              ))}

              {filtered.length > visibleCount && (
                <div className="p-4 bg-slate-50 flex items-center justify-center gap-3">
                  <button
                    type="button"
                    onClick={() => setVisibleCount((prev) => prev + 25)}
                    className="py-2 px-4 rounded-xl bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-bold transition-colors inline-flex items-center gap-1 shadow-2xs"
                  >
                    <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
                    <span>Muat 25 Transaksi Lagi (Sisa {filtered.length - visibleCount})</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setVisibleCount(filtered.length)}
                    className="py-2 px-3 text-xs text-indigo-600 hover:text-indigo-800 font-semibold"
                  >
                    Tampilkan Semua ({filtered.length})
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
