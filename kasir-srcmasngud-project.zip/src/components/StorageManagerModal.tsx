import React, { useState, useEffect, useRef } from 'react';
import { 
  Database, 
  HardDrive, 
  Download, 
  Upload, 
  Trash2, 
  CheckCircle2, 
  AlertTriangle, 
  X, 
  Sparkles, 
  RefreshCw, 
  Archive, 
  ShieldCheck, 
  FileJson,
  Layers,
  Cpu
} from 'lucide-react';
import { 
  getStorageEstimate, 
  StorageEstimateInfo, 
  exportAllDataJSON, 
  importDataJSON, 
  archiveOldTransactions, 
  clearAllTransactionsFromDB, 
  saveProductsToDB 
} from '../utils/db';
import { Product, Transaction } from '../types';
import { INITIAL_PRODUCTS } from '../data/sampleProducts';

interface StorageManagerModalProps {
  onClose: () => void;
  onDataChanged: (products: Product[], transactions: Transaction[]) => void;
}

export const StorageManagerModal: React.FC<StorageManagerModalProps> = ({
  onClose,
  onDataChanged
}) => {
  const [estimate, setEstimate] = useState<StorageEstimateInfo | null>(null);
  const [loading, setLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);
  const [archiveDays, setArchiveDays] = useState<number>(30);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const refreshEstimate = async () => {
    try {
      const data = await getStorageEstimate();
      setEstimate(data);
    } catch {
      // Abaikan
    }
  };

  useEffect(() => {
    refreshEstimate();
  }, []);

  // 1. Unduh Cadangan JSON
  const handleExportBackup = async () => {
    try {
      setLoading(true);
      const jsonStr = await exportAllDataJSON();
      const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      const timestamp = new Date().toISOString().slice(0, 10);
      link.href = url;
      link.download = `backup-kasir-masngud-${timestamp}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      setStatusMessage({
        type: 'success',
        text: 'File cadangan data (JSON) berhasil diunduh ke memori perangkat!'
      });
      await refreshEstimate();
    } catch (e: any) {
      setStatusMessage({
        type: 'error',
        text: 'Gagal mengunduh cadangan: ' + (e?.message || 'Terjadi kesalahan.')
      });
    } finally {
      setLoading(false);
    }
  };

  // 2. Impor / Pulihkan dari File JSON
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        setLoading(true);
        const content = event.target?.result as string;
        const result = await importDataJSON(content);

        if (result.success) {
          onDataChanged(result.products, result.transactions);
          setStatusMessage({
            type: 'success',
            text: result.message
          });
          await refreshEstimate();
        } else {
          setStatusMessage({
            type: 'error',
            text: result.message
          });
        }
      } catch (err: any) {
        setStatusMessage({
          type: 'error',
          text: 'Gagal memproses file: ' + err?.message
        });
      } finally {
        setLoading(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };
    reader.readAsText(file);
  };

  // 3. Arsipkan Transaksi Lama (> X Hari)
  const handleArchive = async () => {
    if (!window.confirm(`Arsipkan & bersihkan riwayat transaksi yang lebih lama dari ${archiveDays} hari? (Data stok barang tetap aman). Disarankan mengunduh cadangan terlebih dahulu.`)) {
      return;
    }

    try {
      setLoading(true);
      const result = await archiveOldTransactions(archiveDays);
      const freshProducts = await import('../utils/db').then((m) => m.getAllProducts());
      onDataChanged(freshProducts, result.remainingTransactions);

      setStatusMessage({
        type: 'success',
        text: `Berhasil mengarsipkan ${result.removedCount} transaksi lama. Sisa ${result.remainingTransactions.length} transaksi aktif.`
      });
      await refreshEstimate();
    } catch (err: any) {
      setStatusMessage({
        type: 'error',
        text: 'Gagal mengarsipkan: ' + err?.message
      });
    } finally {
      setLoading(false);
    }
  };

  // 4. Kosongkan Riwayat Transaksi Saja
  const handleClearTransactionsOnly = async () => {
    if (!window.confirm('Hapus SEMUA riwayat transaksi penjualan? Seluruh daftar produk dan stok tetap dipertahankan aman.')) {
      return;
    }

    try {
      setLoading(true);
      await clearAllTransactionsFromDB();
      const freshProducts = await import('../utils/db').then((m) => m.getAllProducts());
      onDataChanged(freshProducts, []);

      setStatusMessage({
        type: 'success',
        text: 'Riwayat transaksi penjualan berhasil dikosongkan. Beban memori kini maksimal segar!'
      });
      await refreshEstimate();
    } catch (err: any) {
      setStatusMessage({
        type: 'error',
        text: 'Gagal membersihkan: ' + err?.message
      });
    } finally {
      setLoading(false);
    }
  };

  // 5. Reset ke Demo
  const handleResetToDemo = async () => {
    if (!window.confirm('Reset data barang kembali ke 12 produk demo standar toko kelontong dan kosongkan riwayat?')) {
      return;
    }

    try {
      setLoading(true);
      await saveProductsToDB(INITIAL_PRODUCTS);
      await clearAllTransactionsFromDB();
      onDataChanged(INITIAL_PRODUCTS, []);

      setStatusMessage({
        type: 'success',
        text: 'Data berhasil direset ke standar demo awal.'
      });
      await refreshEstimate();
    } catch (err: any) {
      setStatusMessage({
        type: 'error',
        text: 'Gagal reset: ' + err?.message
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/60 backdrop-blur-xs animate-fadeIn">
      <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header Modal */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <HardDrive className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-slate-900 text-base">
                  Kelola Penyimpanan &amp; Optimasi Anti-Lag
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                  IndexedDB Kuota Besar
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Penyimpanan lokal telah dilonggarkan untuk transaksi cepat tanpa macet
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5 text-slate-700 text-xs sm:text-sm">
          
          {/* Notification Message */}
          {statusMessage && (
            <div className={`p-3.5 rounded-2xl border flex items-start gap-2.5 ${
              statusMessage.type === 'success'
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                : statusMessage.type === 'error'
                ? 'bg-rose-50 border-rose-200 text-rose-900'
                : 'bg-indigo-50 border-indigo-200 text-indigo-900'
            }`}>
              {statusMessage.type === 'success' ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              ) : (
                <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              )}
              <div className="flex-1 text-xs sm:text-sm font-medium">
                {statusMessage.text}
              </div>
              <button 
                onClick={() => setStatusMessage(null)}
                className="text-slate-400 hover:text-slate-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Status Kapasitas Storage Card */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-50 to-teal-50/40 border border-emerald-200/80 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4 text-emerald-700" />
                <span className="font-bold text-slate-800 text-sm">
                  Status Database Lokal (IndexedDB)
                </span>
              </div>
              <span className="text-[11px] font-bold text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded-md">
                Kapasitas Dilonggarkan (Asinkron)
              </span>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Aplikasi kini menggunakan <strong>IndexedDB</strong> modern, bukan LocalStorage biasa (yang dulu dibatasi hanya 5MB dan sering macet saat data menumpuk). Data disimpan di penyimpanan internal Android secara asinkron tanpa memperlambat tombol kasir.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-1">
              <div className="bg-white/80 p-2.5 rounded-xl border border-emerald-100">
                <span className="text-[10px] text-slate-500 font-medium">Memori Terpakai</span>
                <p className="text-xs sm:text-sm font-black text-slate-800">
                  {estimate?.usedFormatted || '0 B'}
                </p>
              </div>

              <div className="bg-white/80 p-2.5 rounded-xl border border-emerald-100">
                <span className="text-[10px] text-slate-500 font-medium">Kapasitas Kuota</span>
                <p className="text-xs sm:text-sm font-black text-emerald-700">
                  {estimate?.quotaFormatted || 'Tersedia Banyak (>1 GB)'}
                </p>
              </div>

              <div className="bg-white/80 p-2.5 rounded-xl border border-emerald-100 col-span-2 sm:col-span-1">
                <span className="text-[10px] text-slate-500 font-medium">Total Data Tersimpan</span>
                <p className="text-xs sm:text-sm font-bold text-slate-800">
                  {estimate?.productCount || 0} SKU • {estimate?.transactionCount || 0} Struk
                </p>
              </div>
            </div>
          </div>

          {/* Bagian Cadangkan & Pulihkan (Backup & Restore) */}
          <div className="space-y-3">
            <h4 className="font-bold text-slate-800 text-xs sm:text-sm flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-indigo-600" />
              <span>Cadangkan &amp; Pulihkan Data (Backup Offline)</span>
            </h4>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Export Backup Button */}
              <div className="p-3.5 rounded-2xl border border-slate-200 bg-white hover:border-indigo-300 transition-all space-y-2 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 font-bold text-xs sm:text-sm text-slate-800">
                    <Download className="w-4 h-4 text-indigo-600" />
                    <span>Cadangkan (Download JSON)</span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1">
                    Simpan file cadangan seluruh barang dan transaksi ke folder Unduhan HP/Laptop Anda.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleExportBackup}
                  disabled={loading}
                  className="w-full py-2 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Unduh File Cadangan</span>
                </button>
              </div>

              {/* Import / Restore Button */}
              <div className="p-3.5 rounded-2xl border border-slate-200 bg-white hover:border-emerald-300 transition-all space-y-2 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 font-bold text-xs sm:text-sm text-slate-800">
                    <Upload className="w-4 h-4 text-emerald-600" />
                    <span>Pulihkan (Impor JSON)</span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1">
                    Muat kembali data barang dan transaksi dari file cadangan yang pernah diunduh.
                  </p>
                </div>

                <label className="w-full py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer text-center">
                  <Upload className="w-3.5 h-3.5" />
                  <span>Pilih File Cadangan</span>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".json"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                </label>
              </div>
            </div>
          </div>

          {/* Bagian Perawatan & Pembersihan Memori Anti-Lag */}
          <div className="space-y-3 pt-2">
            <h4 className="font-bold text-slate-800 text-xs sm:text-sm flex items-center gap-1.5">
              <Archive className="w-4 h-4 text-amber-600" />
              <span>Optimasi Performa &amp; Pembersihan Riwayat</span>
            </h4>

            <div className="p-3.5 rounded-2xl border border-slate-200 bg-slate-50/60 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <span className="font-bold text-slate-800 text-xs">
                    Arsipkan Transaksi Lama
                  </span>
                  <p className="text-[11px] text-slate-500">
                    Hapus transaksi yang sudah selesai lama agar daftar riwayat tetap ringan dan gegas saat dibuka.
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <select
                    value={archiveDays}
                    onChange={(e) => setArchiveDays(Number(e.target.value))}
                    className="px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-hidden"
                  >
                    <option value={15}>Lebih dari 15 hari</option>
                    <option value={30}>Lebih dari 30 hari</option>
                    <option value={60}>Lebih dari 60 hari</option>
                    <option value={90}>Lebih dari 90 hari</option>
                  </select>

                  <button
                    type="button"
                    onClick={handleArchive}
                    disabled={loading || (estimate?.transactionCount || 0) === 0}
                    className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs inline-flex items-center gap-1 disabled:opacity-40 transition-colors"
                  >
                    <Archive className="w-3.5 h-3.5" />
                    <span>Arsipkan</span>
                  </button>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <span className="font-bold text-rose-700 text-xs">
                    Kosongkan Semua Riwayat Transaksi
                  </span>
                  <p className="text-[11px] text-slate-500">
                    Hanya menghapus riwayat penjualan. Data barang &amp; stok toko tetap aman.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleClearTransactionsOnly}
                  disabled={loading || (estimate?.transactionCount || 0) === 0}
                  className="px-3 py-1.5 rounded-lg border border-rose-200 hover:bg-rose-50 text-rose-700 font-bold text-xs inline-flex items-center gap-1 disabled:opacity-40 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Kosongkan Transaksi</span>
                </button>
              </div>
            </div>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <button
            type="button"
            onClick={handleResetToDemo}
            className="text-slate-500 hover:text-rose-600 text-xs font-medium inline-flex items-center gap-1"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Reset Demo Awal</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="py-2 px-5 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs transition-colors"
          >
            Tutup
          </button>
        </div>

      </div>
    </div>
  );
};
