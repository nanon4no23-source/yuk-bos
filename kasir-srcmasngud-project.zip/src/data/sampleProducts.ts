import { Product } from '../types';

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod-1',
    name: 'Beras Premium Ramos 5 Kg',
    barcode: '8991001001011',
    category: 'Sembako',
    costPrice: 65000,
    sellingPrice: 72000,
    stock: 24,
    unit: 'karung',
    minStockAlert: 5
  },
  {
    id: 'prod-2',
    name: 'Minyak Goreng Bimoli Pouch 2L',
    barcode: '8991001001028',
    category: 'Sembako',
    costPrice: 32000,
    sellingPrice: 36000,
    stock: 18,
    unit: 'pouch',
    minStockAlert: 5
  },
  {
    id: 'prod-3',
    name: 'Gula Pasir Gulaku 1 Kg',
    barcode: '8991001001035',
    category: 'Sembako',
    costPrice: 15500,
    sellingPrice: 17500,
    stock: 30,
    unit: 'bungkus',
    minStockAlert: 8
  },
  {
    id: 'prod-4',
    name: 'Indomie Goreng Spesial 85g',
    barcode: '8998866200224',
    category: 'Makanan Instan',
    costPrice: 2800,
    sellingPrice: 3500,
    stock: 96,
    unit: 'bungkus',
    minStockAlert: 20
  },
  {
    id: 'prod-5',
    name: 'Indomie Kuah Ayam Bawang',
    barcode: '8998866200231',
    category: 'Makanan Instan',
    costPrice: 2800,
    sellingPrice: 3500,
    stock: 75,
    unit: 'bungkus',
    minStockAlert: 15
  },
  {
    id: 'prod-6',
    name: 'Teh Pucuk Harum 350ml',
    barcode: '8992775211029',
    category: 'Minuman',
    costPrice: 3100,
    sellingPrice: 4000,
    stock: 42,
    unit: 'botol',
    minStockAlert: 10
  },
  {
    id: 'prod-7',
    name: 'Aqua Air Mineral 600ml',
    barcode: '8992753111013',
    category: 'Minuman',
    costPrice: 2700,
    sellingPrice: 3500,
    stock: 48,
    unit: 'botol',
    minStockAlert: 12
  },
  {
    id: 'prod-8',
    name: 'Kopi Kapal Api Spesial Mix 1 Renteng (10 sachet)',
    barcode: '8991389221014',
    category: 'Minuman',
    costPrice: 13500,
    sellingPrice: 16000,
    stock: 15,
    unit: 'renteng',
    minStockAlert: 4
  },
  {
    id: 'prod-9',
    name: 'Susu Kental Manis Frisian Flag Cokelat 370g',
    barcode: '8991002010114',
    category: 'Sembako',
    costPrice: 11500,
    sellingPrice: 13500,
    stock: 3,
    unit: 'kaleng',
    minStockAlert: 5
  },
  {
    id: 'prod-10',
    name: 'Sabun Mandi Lifebuoy Total 10 85g',
    barcode: '8999999052011',
    category: 'Kebutuhan Mandi',
    costPrice: 3800,
    sellingPrice: 4500,
    stock: 22,
    unit: 'pcs',
    minStockAlert: 6
  },
  {
    id: 'prod-11',
    name: 'Deterjen Rinso Molto Anti Noda 770g',
    barcode: '8999999041212',
    category: 'Kebutuhan Rumah',
    costPrice: 19500,
    sellingPrice: 22500,
    stock: 0,
    unit: 'bungkus',
    minStockAlert: 5
  },
  {
    id: 'prod-12',
    name: 'Telur Ayam Negeri 1 Kg (Isi ~16 butir)',
    barcode: '8991001009999',
    category: 'Sembako',
    costPrice: 26000,
    sellingPrice: 29000,
    stock: 14,
    unit: 'kg',
    minStockAlert: 5
  }
];

export const CATEGORIES = [
  'Semua Kategori',
  'Sembako',
  'Makanan Instan',
  'Minuman',
  'Kebutuhan Rumah',
  'Kebutuhan Mandi',
  'Snack & Biskuit',
  'Rokok & Tembakau',
  'Lainnya'
];
